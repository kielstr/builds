#!/bin/bash

set -e
exec ./discover.py "$@"
