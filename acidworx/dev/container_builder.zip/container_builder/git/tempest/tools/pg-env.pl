#!/usr/bin/env perl

use 5.16.0;
use warnings;

use SD::Tempest::Configuration;
my $c = SD::Tempest::Configuration->config->{database};

my %vars = (
    PGHOST      => 'dbhost',
    PGUSER      => 'user',
    PGDATABASE  => 'dbname',
);

while (my ($var, $key) = each %vars) {
    say "export $var=$c->{$key};";
}

__END__

=head1 NAME

pg-env.pl - scrape PGXXX environment variables from tempest config

=head1 SYNOPSIS

In your shell:

    $ eval $( tools/pg-env.pl )

=head1 DESCRIPTION

Consults the tempest configuration and prints out the corresponding PostgreSQL
environment variables.

=cut
