#!/bin/sh

if [ $# != 1 ]; then
    echo usage: $0 repo-path
    exit 1
fi

set -e

REPO_PATH=$( readlink -m $1 )
SERVER_PORT=5001

svnadmin create $REPO_PATH

cat > $REPO_PATH/conf/svnserve.conf <<END_SVNSERVE
[general]
anon-access = read
auth-access = write
realm = Test Repo
password-db = passwd
END_SVNSERVE

cat > $REPO_PATH/conf/authz <<END_AUTHZ
[groups]
users = tempest, user
[$REPO_PATH]
users = rw
END_AUTHZ

cat > $REPO_PATH/conf/passwd <<END_PASSWD
[users]
tempest = tempest
user = user
END_PASSWD

cat > $REPO_PATH/start-svn.sh <<END_START
#!/bin/sh
svnserve -d -r $REPO_PATH --listen-port $SERVER_PORT --pid-file $REPO_PATH/pid
echo SVN server started on svn://localhost:$SERVER_PORT/
END_START
chmod +x $REPO_PATH/start-svn.sh

cat > $REPO_PATH/stop-svn.sh <<END_STOP
#!/bin/sh
kill \`cat $REPO_PATH/pid\`
END_STOP
chmod +x $REPO_PATH/stop-svn.sh

cat > $REPO_PATH/stop-svn.sh <<END_STOP
#!/bin/sh
kill \`cat $REPO_PATH/pid\`
END_STOP
chmod +x $REPO_PATH/stop-svn.sh

cat > $REPO_PATH/hooks/post-commit <<'END_HOOK'
#!/bin/sh
REPOS="$1"
REV="$2"
AUTHOR=$( svnlook author -r "$REV" "$REPOS" )
logger -t tempest/svn-post-commit -i AUTHOR="$AUTHOR"
if [ "$AUTHOR" = "tempest" ]; then
    logger -t tempest/svn-post-commit -i Skipping commit from tempest
else
    # HOST=$( hostname -s ) # <-- need this in real life
    HOST=localhost
    logger -t tempest/svn-post-commit -i GET "http://localhost:5000/repo-changed/$HOST/$REV"
    GET -d "http://localhost:5000/repo-changed/$HOST/$REV" &
fi
END_HOOK
chmod +x $REPO_PATH/hooks/post-commit

echo Created SVN repo at $1
echo Use $1/start-svn.sh to start the server \(starting now\)

$REPO_PATH/start-svn.sh

echo Use $1/stop-svn.sh to stop the server

#echo repo svn://localhost:$SERVER_PORT/ >> websurvey-tempest_local.conf
