#!/bin/sh

# This script can be used to initialise or update the tempest submodules.
# On a fresh tempest checkout, this will fetch all the submodules and modify
# the push remote url to be read-write.
# On an existing checkout, will synchronise and update the submodules.

export root=$(  git remote -v show | grep push | cut -d@ -f2 | cut -d/ -f1 )

git submodule sync
git submodule foreach --recursive 'git submodule sync'
git submodule update --init --recursive
git submodule foreach --recursive 'git remote set-url --push origin git@${root}/$( basename $name )'
