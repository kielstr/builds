#!/usr/bin/env perl
use warnings;
use strict;

use lib 't/lib';
use Tempest::Test::Fixture::Database;

my $db = Tempest::Test::Fixture::Database->new;
my $schema = $db->schema;

use SQL::Translator;
my $trans = SQL::Translator->new(
    parser => 'SQL::Translator::Parser::DBIx::Class',
    parser_args => { package => $schema },
    producer => 'GraphViz',
    producer_args => {
        out_file => 'tempest-schema.png',
        layout => 'dot',
        node => {
            fillcolor => 'AntiqueWhite',
        },
        title => 'SD::Tempest::Schema',
        show_constraints => 1,
        show_datatypes   => 1,
        show_sizes       => 1,
        # Undocumented feature - setting to zero seems to mean automatic:
        height => 0,
        width => 0,
    },
) or die SQL::Translator->error;
$trans->translate or die $trans->error;

