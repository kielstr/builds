#!/usr/bin/env perl
use 5.16.3;
use warnings;
use strict;

use SD::Tempest::Mutator::SurveyInstance;
use SD::Tempest::Mutator::Component;
use URI;

my $domain = ".testing.websurvey.net.au";

use SD::Tempest::Configuration;
use SD::Tempest::Schema;
use SD::Tempest::SVN::Client;

my $config = SD::Tempest::Configuration->config;
my $schema = SD::Tempest::Schema->connect($config->{database});

my $svn_client = SD::Tempest::SVN::Client->new(
    %{ $config->{ldap} },
);

# Find all inactive instances
my $instance_rs = $schema->resultset('SurveyInstance')->search(
    {
        inactive => [ undef, { '!=' => 1 } ],
        'deployment.name' => 'testing'
    },
    {
        prefetch => [ { 'survey' => 'client' }, {'instance_generation' => 'generation' }, 'deployment' ],
        order_by => [ 'client_tag', 'survey_tag' ],
    }
);

while ( my $instance = $instance_rs->next ) {
    # Checkout instance and get all components
    my $mutator = SD::Tempest::Mutator::SurveyInstance->new(
        svn_client => $svn_client,
        instance   => $instance,
    );
    for my $component ( $mutator->components ) {
        my $dev_url = URI->new(
            $component->properties->{frontend_urls}{development}
        );
        my ($host) = split('\.', $dev_url->host);
        my $test_url = $dev_url->clone;
        $test_url->host( $host . $domain );
        my $cm = SD::Tempest::Mutator::Component->new(
            mutator   => $mutator,
            component => $component
        );
        $cm->set_url( 'tempest', 'testing' => $test_url );
    }
}
