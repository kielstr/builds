#!/usr/bin/env perl
use 5.14.1;
use warnings;

use lib './t/lib';
use Tempest::Test::Fixture::Database;

my $env = 'TEMPEST_TEST_PG';

die "ERROR: Postgres already running: $ENV{$env}" if $ENV{$env};

# Crank up a database
say STDERR 'Starting database server';
my $tdb = Tempest::Test::Fixture::Database->new();
say STDERR 'Database server started on: ', $tdb->dsn;

# Set TEMPEST_TEST_PG environment variable
$ENV{$env} = $tdb->dsn;

# If the user has specified a command, run that, otherwise shell out.
if (@ARGV) {
    system(@ARGV);
}
else {
    my @cmd = ( $ENV{SHELL} );
    say STDERR 'Spawning new shell - exit to stop the database server';
    system(@cmd);
}

# We're back - delete the database and we're done.
undef $tdb;

__END__

=pod

=head1 NAME

create_test_db.pl

=head1 DESCRIPTION

Creates a long-running temporary postgres instance that can be reused for tests.

Saves needing to create a whole postgres server for each individual test.

Can be used in batch mode, or interactively.

=head1 SYNOPSIS

    # Batch mode - runs command with access to temporary server
    $> ./tools/create_test_db.pl prove -r t


    # Interactive mode
    $> ./tools/create_test_db.pl

        Starting database server
        Database server started on:
            DBI:Pg:dbname=test;host=127.0.0.1;port=15434;user=postgres
        Spawning new shell - exit to stop the database server

    $> ... do stuff, run tests etc

    # Exit this sub-shell to kill the temporary server
    $> exit

        Waiting for Pg to terminate..

=cut
