#!/bin/bash -x
# This script should run a full test suite, including extra environment
# variables, code coverage, etc. *AND* clean up afterwards, you filthy
# test-suites, you!

if [ -n "$JENKINS_HOME" ]; then
    # Grab the submodules if we are running on hudson, otherwise assume the
    # user already has them (not 100% sure about this...)
    git submodule update --init --recursive
    git submodule foreach --recursive git pull origin master
fi

source shell_vars

export TEST_VERBOSE=1
export AUTOMATED_TEST=1
export SD_CREATE_TEST_DB=1
export SD_TEST_DB_HOST=localhost

# Enable parallel testing. Comment this out if it becomes problematic.
PARALLEL_JOBS=4

if [ -n $PARALLEL_JOBS ]; then
    export HARNESS_OPTIONS=j$PARALLEL_JOBS
    export PROVE_OPTIONS=-j$PARALLEL_JOBS
fi

# Our temporary directories don't seem to be cleanin up after themselves, so
# instead just put them in one place, and delete them all at the end.
# This relies on the temporary directories honouring $TMPDIR, but seems to work
# at the moment.
export TMPDIR=$( mktemp -d )

perl Makefile.PL
make
rm -f junit_output.xml
prove $PROVE_OPTIONS --blib --harness TAP::Harness::JUnit -rv t/

cover -delete
HARNESS_PERL_SWITCHES=-MDevel::Cover=+ignore,.,-select,blib/lib/ make test
cover -outputdir cover_html

make clean
rm -rf $TMPDIR
