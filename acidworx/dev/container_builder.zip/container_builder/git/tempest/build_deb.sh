#!/bin/bash

# Set up the required env
source shell_vars
PATH=/usr/share/strategic/bin:"$PATH"

# Remove old, stale files
debuild clean

# Build away
debuild --preserve-envvar=USER --preserve-envvar=TEMPEST_TEST_PG --preserve-envvar=PERL5LIB --preserve-envvar=PATH --preserve-envvar=SD_WEBSURVEY_CONFIG \
    -us -uc -rfakeroot -i -I -d -b \
    --lintian-opts \
    --suppress-tags-from-file ${PWD}/debian/lintian_tags
