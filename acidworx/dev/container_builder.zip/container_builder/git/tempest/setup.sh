#!/bin/bash -e
apt-get update
apt-get install -y subversion libsvn-dev

pushd /tmp/setup/

# If these aren't installed first, failure occur later.
# (In the case of Any::Moose, it's intermittent)
cpanm $CPANM_ARGS Module::Install::Catalyst Any::Moose Method::Signatures Log::Any::Adapter::FileHandle

# Used to prevent Test::SVN::Repo being installed by Makefile.PL
export SD_DOCKER_BUILD=1

# WebSurvey::Platform
cpanm $CPANM_ARGS https://gh.sdintra.net/WebSurvey/websurvey-platform.git

# WebSurvey (core)
cpanm --notest $CPANM_ARGS https://gh.sdintra.net/WebSurvey/websurvey.git@feature/rip-squeeze
# global defaults file
mkdir /etc/sd-websurvey-4.0
curl -Ls -o /etc/sd-websurvey-4.0/global_defaults.pl \
    https://gh.sdintra.net/WebSurvey/websurvey/raw/feature/rip-squeeze/conf/global_defaults.pl

# survey content dependencies
install-cpan-modules modules.txt

# Can't seem to build Test::SVN::Repo within docker
cpanm --notest $CPANM_ARGS .
popd
rm /tmp/setup.sh
rm -rf /tmp/setup/
rm -rf /root/.cpanm
exit 0
