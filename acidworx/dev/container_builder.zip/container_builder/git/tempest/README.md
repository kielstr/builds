### INITIAL SETUP

Clone the repo:

    $ git clone git@gh.mel.strategicdata.com.au:WebSurvey/tempest.git

Initialise the submodules:

    $ cd tempest
    $ ./tools/update-submodules.sh


### CONFIGURATION

Copy websurvey-tempest_local.conf-sample to websurvey-tempest_local.conf and adjust to taste. The paths are set up to correspond to the submodule layout, and the provided database credentials may suit.

Edit this local configuration to suit. You should be able to use it directly.

Then, initialise your environment:

    $ source shell_vars


### DEVELOPMENT DATABASE

Create a development database with:

    $ ./script/sd-tempest-database --create install

Populate the development database with:

    $ ./script/sd-tempest-extract-repo-tags


### TESTING

Tempest tests use Test::PostgreSQL to create a temporary database server. Doing this for each test can be quite slow, so this database can be created and left running with:

    $ ./tools/create_test_db.pl

The tests will detect this database (via the TEMPEST_TEST_PG variable), and use it rather than creating a new one.


The tempest tests can be run concurrently, speeding up the test suite quite a bit. For example:

    $ prove -r -j4 --state=slow,save --timer t/


Here's some sample testsuite timings running on fitz-dev004 (in seconds):
```
            Pre-built database
            |  off   on
        ----+------+-------
   Jobs:   1|  532 | 162
           4|  108 |  57
```
