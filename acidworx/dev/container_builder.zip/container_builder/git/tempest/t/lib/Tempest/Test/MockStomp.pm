package Tempest::Test::MockStomp;
use 5.16.0;
use Moose;
use namespace::autoclean;

has _args => (
    is      => 'ro',
    isa     => 'ArrayRef[HashRef]',
    traits  => ['Array'],
    default => sub { [] },
    handles => {
        add_args   => 'unshift',
        get_args   => 'pop',
        args_count => 'count',
        reset_args => 'clear',
    },
);

has message_callback_enabled => (
    traits  => ['Bool'],
    is => 'rw',
    isa => 'Bool',
    default => sub { 1 },
    handles => {
        enable_message_callbacks => 'set',
        disable_message_callbacks => 'unset',
    },
);

# Mocked version of send just appends its arguments to the _args array
sub send {
    my $self = shift;
    $self->add_args({ @_ });
    return;
}

# Mocked version of message_callback just calls the callback immediately,
# unless message_callback_enabled is false
sub message_callback {
    my ($self, $callback) = @_;
    if ($self->message_callback_enabled) {
        $callback->();
    }
}

sub uuid {
    my $self = shift;
    return "$self";
}

for (qw( receipts wait_for_frames wait_for_receipts )) {
    __PACKAGE__->meta->add_method($_ => sub { });
}

# Role::Stomp is insisting that the stomp attribute isa 'Net::STOMP::Client'.
# We can fake it here like so. Not sure if this is the best way to do it, but
# it seems to work.
sub isa {
    return 1 if $_[1] eq __PACKAGE__;
    return 1 if $_[1] eq 'Net::STOMP::Client'; # Fake it for Role::Stomp
    return;
}

__PACKAGE__->meta->make_immutable;
1;
