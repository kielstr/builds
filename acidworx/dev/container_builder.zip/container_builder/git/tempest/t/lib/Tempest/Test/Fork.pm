package Tempest::Test::Fork;
use warnings;
use strict;

use Exporter 'import';
our @EXPORT = (qw/child wait_for_all_children wait_for_children trapped_output
                  run_in_child_and_get_exit_code/);

use Carp qw(croak);
use Path::Class qw();

sub child (&) {
    my $code = shift;

    my $pid = fork;

    if ( ! defined $pid) {
        croak "Fork failed: $!";
    }
    elsif ( $pid ) {                # parent
        return $pid;
    }
    else {        # child
        # Trap STDERR
        open( STDERR, "+>", undef );
        tie *STDERR, "Tempest::Test::TrapOutput";
        $code->();
        exit;
    }
}

# Need to specify child count, or long-running processes like Test::pg make
# this hang.
sub wait_for_children {
    my ($count) = @_;
    for (my $i = 0; $i < $count; $i++) {
        my $kid = waitpid(-1, 0);
        return $i if $kid <= 0;
    }
    return $count;
}

# Slurp back the output
sub trapped_output {
    my $filename = $Tempest::Test::TrapOutput::filename;
    my $output = Path::Class::File->new( $filename )->slurp;
    open my $fh, '>', $filename; # reset output file
    return join "\n",
        grep { $_ !~ /^Devel::Cover: Warning/ } split("\n", $output);
}

sub run_in_child_and_get_exit_code (&) {
    my $code = shift;

    if (my $pid = fork) {
        # Parent - return exit code from child
        waitpid($pid, 0);
        return $?;
    }
    else {
        # Child - exit with return value of coderef
        exit $code->();
    }
}

package Tempest::Test::TrapOutput;
use warnings;
use strict;

use File::Temp qw();
use Scope::Guard;

# Temp file name for capturing output.
our $filename;
# Scope::Guard object - cleans up our temporary file.
our $guard;
# This is only used in forking tests - ensure the cleanup is only done in
# the parent process
my $pid = $$;

BEGIN {
    my $temp = File::Temp->new( UNLINK => 0 );
    $filename = $temp->filename;
	print $temp '';
    close $temp;
    # Ensure we clean up after ourselves
    $guard = Scope::Guard->new( sub { unlink $filename if $$ == $pid } );
}

sub TIEHANDLE {
    my $class = shift;
    bless [], $class;
}

sub PRINT {
    my $self = shift;
    open my $fh, ">>", $filename;
    binmode $fh, ":utf8";
    print $fh @_;
    close $fh;
}

sub FILENO { -2 }

1;

__END__

=pod

=head1 NAME

Tempest::Test::Fork - helpers for tests that fork

=cut
