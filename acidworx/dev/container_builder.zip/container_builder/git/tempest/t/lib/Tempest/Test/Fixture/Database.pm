package Tempest::Test::Fixture::Database;

use Moose;
use namespace::autoclean;

use Test::PostgreSQL;

use SD::Tempest::Configuration;
use SD::Tempest::DeploymentHandler;
use SD::Tempest::Schema;

use Carp qw( croak );
use DBI;

has 'schema' => (
    is          => 'ro',
    isa         => 'SD::Tempest::Schema',
    clearer     => '_clear_schema',
    lazy_build  => 1,
);

sub _build_schema {
    my $self = shift;
    return SD::Tempest::Schema->connect($self->config->{ $self->config_key });
}

sub BUILD {
    my ($self) = @_;

    my $dbconfig = $self->config->{ $self->config_key };

    $dbconfig->{dsn} = $self->dsn;
    delete $dbconfig->{user};
    delete $dbconfig->{password};

    $self->_deploy;
}

sub DEMOLISH {
    my ($self) = @_;
    # Had some warningsa about storage being undef at this point
    if ($self && $self->schema && $self->schema->storage) {
        $self->schema->storage->disconnect;
    }
    $self->_clear_schema; # so that we've got no handles to the database
}

sub create_client {
    my ($self, $client_id, $schema) = @_;
    $schema //= $self->schema;

    my $row = $schema->resultset('Client')
                     ->find_or_create({ client_tag => $client_id });

    return $row;
}

sub find_survey {
    my ($self, $client_id, $survey_id, $schema) = @_;
    $schema //= $self->schema;

    my $row = $self->create_client($client_id, $schema)
                   ->surveys
                   ->find_or_create({survey_tag => $survey_id});

    return $row;
}

sub _deploy {
    my ($self) = @_;

    my $dh = SD::Tempest::DeploymentHandler->new(
        quiet => 1,
        testing => 1,
        force => 1,
    );

    $dh->generate_meta;
    $dh->install;
    $dh->schema->storage->disconnect;
}

has config => (
    is          => 'ro',
    lazy        => 1,
    default     => sub { SD::Tempest::Configuration->config },
);

has dsn => (
    is          => 'ro',
    isa         => 'Str',
    lazy_build  => 1,
);

has config_key => (
    is          => 'ro',
    isa         => 'Str',
    default     => 'database',
);

has extra_initdb_args => (
    is          => 'ro',
    isa         => 'Str',
    lazy        => 1,
    default     => '--encoding=utf8',
);

has initdb_args => (
    is          => 'ro',
    isa         => 'Str',
    lazy        => 1,
    default     => sub {
            $Test::PostgreSQL::Defaults{initdb_args}
            . ' '
            . shift->extra_initdb_args
        },
);

has _pg => (
    is          => 'ro',
    isa         => 'Test::PostgreSQL',
    lazy        => 1,
    default     => sub {
            Test::PostgreSQL->new(initdb_args => shift->initdb_args)
        },
);

sub _build_dsn {
    my $self = shift;

    if ($ENV{TEMPEST_TEST_PG}) {
        # Create a new database in the existing Test::PostgreSQL instance
        return $self->_create_database($ENV{TEMPEST_TEST_PG});
    }
    else {
        # Create a new Test::PostgreSQL instance
        return $self->_pg->dsn;
    }
}

sub _create_database {
    my ($self, $dsn) = @_;

    # Create a unique db name so we can run tests in parallel
    my $unique = $$ . time;
    my $dbname = "tempest_test_$unique";
    my $dbh = DBI->connect($dsn, '', '', {}) or croak $DBI::errstr;

    my @sql = (
        "SET client_min_messages TO 'WARNING'",
        "DROP DATABASE IF EXISTS $dbname",
        "CREATE DATABASE $dbname",
        "RESET client_min_messages",
    );
    for (@sql) {
        $dbh->do($_) or croak $dbh->errstr;
    }

    $dsn =~ s/test/$dbname/;
    return $dsn;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=head1 NAME

Tempest::Test::Fixture::Database - Postgres database fixtures for testing

=head1 SYNOPSIS

    my $db = Tempest::Test::Fixture::Database->new;
    my $schema = $db->schema;

=head1 DESCRIPTION

Creates and deploys a temporary PostgreSQL database.

Creates a private database cluster, which requires no special privileges to run.
ie. You don't need to set up special pg users and passwords.

=head1 METHODS

=head2 new

Creates the database instance and deploys the schema.

=head2 schema

Returns a new schema object.

=head1 BEWARE

When the object goes out of scope, the database is deleted. Make sure you keep
a reference.

=cut
