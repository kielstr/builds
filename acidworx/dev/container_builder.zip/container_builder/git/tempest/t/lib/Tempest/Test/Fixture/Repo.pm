package Tempest::Test::Fixture::Repo;

use strict;
use warnings;

use base qw( Class::Accessor );

use Carp qw( confess );
use Test::SVN::Repo;

__PACKAGE__->mk_ro_accessors(qw( repo ));

#------------------------------------------------------------------------------

sub new {
    my ($class, %args) = @_;

    $args{keep_files} = $ENV{TEMPEST_KEEP_FILES}
        if $ENV{TEMPEST_KEEP_FILES};

    $args{verbose} = 1
        if $ENV{TEMPEST_VERBOSE_SVN};

    my $self = bless {}, $class;

    $self->{repo} = Test::SVN::Repo->new(%args);
    $self->_setup_checkout;

    return $self;
}

my $subdir = 'tempest';

sub url             { shift->repo->url . "/$subdir" }
sub base_path       { shift->repo->repo_path->parent }
sub checkout_path   { shift->base_path->subdir('checkout', $subdir) }

#------------------------------------------------------------------------------

sub _diag {
    use feature 'say';
    my @a = @_;
    for (@a) {
        chomp; s/^/# /mg;
        say STDERR $_;
    }
}

sub _setup_checkout {
    my ($self) = @_;

    my $svn = $self->_svncmd;
    my $repo_url = $self->url;
    $self->_do_svn($svn, "mkdir $repo_url -m'Creating survey repo'");

    my $checkout_dir = $self->checkout_path;
    my $checkout_output = $self->_do_svn($svn, "co $repo_url $checkout_dir");
    confess "svn co failed: $checkout_output" unless -d $checkout_dir;
}

sub _do_svn {
    my ($self, $svn, $command) = @_;
    my $output = `$svn $command`;

    confess "'$command' failed: $output" if $?;
    _diag($command, $output) if $self->repo->verbose;
    return $output;
}

sub _svncmd {
    my ($self) = @_;
    my $svn = 'svn --no-auth-cache --non-interactive';
    if ($self->repo->is_authenticated) {
        my ($user, $pass) = %{ $self->repo->users }; # grab the first one
        $svn .= " --username $user --password \'$pass\'";
    }
    return $svn;
}

1;

__END__

=pod

=head1 NAME

Tempest::Test::Fixture::Repo - SVN repository fixtures for tempest testing

=head1 SYNOPSIS

use Tempest::Test::Fixture::Repo;

# Create a repo with no password authentication
my $repo = Tempest::Test::Fixture::Repo->new(
        deployments => [qw( testing staging )]
    );

# Create a repo with password authentication
my $repo = Tempest::Test::Fixture::Repo->new(
        deployments => [qw( testing staging )],
        users => { joe => 'secret', fred => 'foobar' },
    );

=head1 ATTRIBUTES

=head2 users

Hashref containing username/password pairs.

If this attribute is specified, there must be at least one user.
If you want no users, don't specify this attribute.

=head2 has_auth

True if the users attribute was specified.

=head2 base_path

Base path to create the repo. Defaults to a temporary directory.

=head2 keep_files

If no base path is provided, this controls whether the temporary directory
should be automatically deleted.

Defaults to false. Can be overridden with TEMPEST_KEEP_FILES environment
variable.

=head2 deployments

List of deployments to use. Defaults to ('testing').

=head2 show_svn_output

SVN output is traced when this is true. Defaults to ENV{TEST_VERBOSE} or false.

=head2 repo_path

Path to the SVN repository.

=head2 url

URL form of repo_path

=head2 checkout_path

Path to the checkout directory.

=head1 METHODS

=head2 create_survey_fixture(%fixture_args)

Convenience function to create a Tempest::Test::Fixture::Survey in the repo,
and commit all the files it created.

Automatically passes the base_path and deployments parameters. All parameters
are passed through to the Tempest::Test::Fixture::Survey constructor.

=cut
