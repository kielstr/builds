package Tempest::Test::Fixture::Survey;

use Moose;
use namespace::autoclean;

use autodie;
use File::Copy;
use MooseX::Types::Path::Class;
use Path::Class     qw();
use List::MoreUtils qw(uniq);
use Scalar::Util qw(blessed);
use Tempest::Test;

has 'file_content' => (
    is          => 'ro',
    isa         => 'HashRef',
    lazy        => 1,
    builder     => 'default_file_content',
);

has 'client_id' => (
    is          => 'ro',
    isa         => 'Str',
    default     => 'test_client',
);

has 'survey_id' => (
    is          => 'ro',
    isa         => 'Str',
    default     => 'test_survey',
);

has 'component_id' => (
    is          => 'ro',
    isa         => 'Str',
    predicate   => 'has_component_id',
);

has 'base_path' => (
    is          => 'ro',
    isa         => 'Path::Class::Dir',
    coerce      => 1,
    default     => sub { Tempest::Test::tempdir },
);

sub BUILD {
    my ($self) = @_;

    my $path = $self->deployment_path;
    $path->mkpath;  # create the dir just in case there are no files
    while (my ($filename, $filedata) = each %{ $self->file_content }) {
        _write_file($path->file($filename), $filedata);
    }
}

sub default_file_content {
    my ($self_or_class) = @_;

    my $properties_yaml = <<'END';
---
component_id: __uuid__
frontend_urls:
    testing: http://dev.example.com/survey/
    staging: http://test.example.com/survey/
    production: http://example.com/survey/
END

    my $config_pl = <<'END';
use SD::WebSurvey::StockComponentConfig;
return SD::WebSurvey::StockComponentConfig->conf(
    survey_name => "__uuid__",
    tt_inc => ["/path/to/tt/stuff"],
);
END

    my $content_pl = <<'END';
return {};
END

    if ( blessed($self_or_class) && $self_or_class->has_component_id ) {
        my $uuid = $self_or_class->component_id;
        s/__uuid__/$uuid/ for ($properties_yaml, $config_pl, $content_pl)
    }

    return {
        'conf/properties.yaml' => $properties_yaml,
        'conf/config.pl'       => $config_pl,
        'conf/content.pl'      => $content_pl,
    };
}

sub deployment_path {
    my ($self) = @_;
    my $path = $self->base_path->subdir($self->client_id)
                               ->subdir($self->survey_id)
                               ;
    $path = $path->subdir($self->component_id) if $self->has_component_id;
    return $path;
}

sub _write_file {
    my $file = shift;
    $file->parent->mkpath unless -e $file->parent;
    print {$file->openw} @_;
    return;
}


__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

Tempest::Test::Fixture::Survey - Survey fixture for tempest testing

=head1 SYNOPSIS

# If you need a repo as well as a survey
use Tempest::Test::Fixture::Repo;
use Tempest::Test::Fixture::Survey;

my $repo = Tempest::Test::Fixture::Repo( );
my $survey_fixture = $repo->create_survey_fixture(
        client_id => '...', survey_id => '...' );

# ... or if you just need a survey
use Tempest::Test::Fixture::Survey;
my $survey_fixture = $repo->create_survey_fixture(
        client_id => '...', survey_id => '...' );

# Then to get an actual survey object
my $survey = $survey_fixture->find_survey;

=head1 ATTRIBUTES

=head2 base_path

Base path to create the survey files. Defaults to a temporary directory.

=head2 keep_files

If no base path is provided, this controls whether the temporary directory
should be automatically deleted.

Defaults to false. Can be overridden with TEMPEST_KEEP_FILES environment
variable.

=head2 file_content

Hashref containing filename=>content pairs of survey files. Defaults to a
barebones survey with config.pl and properties.yaml. Default value is also
available with the default_file_content class method.

=head2 client_id

Defaults to 'test_client'

=head2 survey_id

Defaults to 'survey_id'.

=head2 component_id

No default. Only used if specified.

=head1 METHODS

=head2 new

Writes the survey files out to the specified directories.

=head2 Tempest::Test::Fixture::Survey->default_file_content

This is the default value of file_content. Available separately in case you
want to augment the defaults.

=head2 deployment_path

Returns the path.

=head2 find_survey

Convenience function to create an SD::Tempest::Survey instance.
Passes in the appropriate ids and paths.

=cut
