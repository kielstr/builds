package Tempest::Test::Fixture;
use Moose;
use namespace::autoclean;

use Data::Printer;
use Data::Dumper::Concise;
use File::Temp;
use MooseX::StrictConstructor;
use Path::Class;
use Try::Tiny;

use SD::Tempest::Committer;
use SD::Tempest::Schema;
use SD::Tempest::SVN::Client;

use Tempest::Test::Fixture::Database;
use Tempest::Test::Fixture::Repo;
use Tempest::Test::Fixture::Survey;
use Tempest::Test::MockStomp;

#-------------------------------------------------------------------------------

has database => (
    is          => 'ro',
    isa         => 'Tempest::Test::Fixture::Database',
    lazy_build  => 1,
    handles => [qw( schema )],
);

has repo => (
    is          => 'ro',
    isa         => 'Tempest::Test::Fixture::Repo',
    lazy_build  => 1,
    handles => {
            svn_root      => 'url',
            checkout_root => 'checkout_path',
        },
);

has stomp => (
    is          => 'ro',
    isa         => 'Tempest::Test::MockStomp',
    lazy_build  => 1,
);

has svn_client => (
    is          => 'ro',
    isa         => 'SD::Tempest::SVN::Client',
    lazy_build  => 1,
);

has users => (
    is          => 'ro',
    isa         => 'Maybe[HashRef]',
    lazy_build  => 1,
);

has _deployments => (
    is          => 'ro',
    isa         => 'ArrayRef',
    traits      => ['Array'],
    lazy_build  => 1,
    handles     => {
        deployments => 'elements',
        deployment  => 'get',
    },
);

has _generations => (
    is          => 'ro',
    isa         => 'ArrayRef',
    traits      => ['Array'],
    lazy_build  => 1,
    handles     => {
        generations => 'elements',
        generation  => 'get',
    },
);

#-------------------------------------------------------------------------------

sub generate_survey {
    my ($self, %args) = @_;

    my $client_id = $args{client_id};
    my $survey_id = $args{survey_id};

    my $component_ids = delete $args{component_ids} // [''];

    # Set up database records
    my $survey_rs = $self->database->find_survey($client_id, $survey_id);

    # Create svn directory structure where it does not exist
    my $client_path = join( '/', $self->svn_root, $client_id );
    try {
        my $client_rev = $self->svn_client->revision( $client_path );
    } catch {
        $self->svn_client->mkdir( $client_path, "Creating client $client_id" );
    };

    # Check if survey exists (it shouldn't if old_rev is not true)
    my $survey_path = join('/', $client_path, $survey_id );
    try {
        my $old_rev = $self->svn_client->revision( $survey_path );
    } catch {
        $self->svn_client->mkdir( $survey_path, "Creating $survey_path" );
    };

    # Check out existing content into a temp directory.
    my $dir = Path::Class::Dir->new(Tempest::Test::tempdir);

    # Work around survey fixture assumptions
    my $survey_dir = $dir->subdir( $client_id, $survey_id );
    $survey_dir->mkpath;
    $self->svn_client->checkout( $survey_path, $survey_dir, 'HEAD' );

    # Commit to svn and database
    my $committer = $self->create_committer(client_id => $client_id,
                                            survey_id => $survey_id);

    # If multiple IDs are specified, create N surveys
    for my $id (@{ $component_ids }) {
        Tempest::Test::Fixture::Survey->new(
            base_path => $dir,
            %args,
            component_id => $id,
        );
    }

    # Commit to svn
    for my $child ( $survey_dir->children ) {
        next if $child =~ m/\/\.svn$/;
        $self->svn_client->add( $child );
    }
    $committer->commit( path => $survey_dir, verb => 'Create');

    # Update local checkout
    $self->svn_client->update( $self->checkout_root );

    return $survey_rs;
}

sub find_survey {
    my ($self, %args) = @_;
    return $self->rs('Survey')->find_survey(
        $args{client_id}, $args{survey_id}
    );
}

# required: client_id, survey_id, deployment
sub find_survey_instance {
    my ($self, %args) = @_;

    my $survey = $self->find_survey( %args );
    return $survey->find_instance( $args{'deployment'} );
}

# required: client_id, survey_id, deployment
sub create_survey_instance_mutator {
    my ($self, %args) = @_;

    # must supply: client_id, survey_id, deployment
    return SD::Tempest::Mutator::SurveyInstance->new(
        instance      => $self->find_survey_instance(%args),
        svn_client    => $self->svn_client,
    );
}

# required: client_id, survey_id (names, not db id's)
sub create_committer {
    my ($self, %args) = @_;;
    return SD::Tempest::Committer->new(
            schema      => $self->schema,
            svn_client  => $self->svn_client,
            %args,
        );
}

sub create_committer_for_instance {
    my ($self, $survey_instance) = @_;

    $self->create_committer(
        survey_id => $survey_instance->survey->survey_tag,
        client_id => $survey_instance->survey->client->client_tag,
    );
}

sub rs {
    my ($self, $name) = @_;
    return $self->schema->resultset($name);
}

sub svn_path_to {
    my $self = shift;
    return join('/', $self->svn_root, @_);
}

sub checkout_path_to {
    my $self = shift;
    return $self->checkout_root->subdir(@_);
}

sub params {
    my $self = shift;
    return map { $_ => $self->$_ } @_;
}

sub repo_revision {
    my ($self, $svn_path) = @_;
    $svn_path //= $self->svn_root;

    return int($self->svn_client->revision($svn_path));
}

sub audit_log {
    my ($self) = @_;
    return $self->rs('AuditLog');
}

sub dump_audit_log {
    my ($self) = @_;
    say STDERR Dumper($self->audit_log->chronologically->search({}, {
        result_class => 'DBIx::Class::ResultClass::HashRefInflator',
    })->all);
}

sub commit_survey_instance_modification {
    my ($self, $survey_instance, $coderef) = @_;

    $coderef //= sub {
        my ($svn, $path) = @_;
        my ($fh, $filename) = $path->tempfile;
        $svn->add($filename);
    };

    my $temp = File::Temp->newdir;
    my $path = Path::Class::Dir->new($temp);
    my $svn = $self->svn_client;

    $svn->checkout($survey_instance->svn_path, $path);
    my $message = $coderef->($svn, $path) // 'update';

    my $committer = $self->create_committer_for_instance($survey_instance);

    return $committer->commit(path => $path, verb => $message);
}

#-------------------------------------------------------------------------------

sub _build_database {
    my ($self) = @_;
    return Tempest::Test::Fixture::Database->new;
}

sub _build_repo {
    my ($self) = @_;
    my %args;
    $args{users} = $self->users if $self->users;
    return Tempest::Test::Fixture::Repo->new(%args);
}

sub _build_svn_client {
    my ($self) = @_;
    my $users = $self->users;
    if ($self->users) {
        my @users = %{ $self->users };
        return SD::Tempest::SVN::Client->new(username => $users[0],
                                             password => $users[1]);
    }
    return SD::Tempest::SVN::Client->new;
}

sub _build_stomp {
    my ($self) = @_;
    return Tempest::Test::MockStomp->new;
}

sub _build_users {
    return $ENV{TEMPEST_TEST_FORCE_NOAUTH} ? undef
                                           : { 'testuser' => 'testpassword' }
}

sub _build__deployments {
    my ($self) = @_;
    return [ $self->schema->resultset('Constraint::Deployment')->names ];
}

sub _build__generations {
    my ($self) = @_;
    return [ $self->schema->resultset('Constraint::Generation')->names ];
}

#-------------------------------------------------------------------------------

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

Tempest::Test::Fixture - One-stop shopping for test fixtures

=head1 SYNOPSIS

    my $fixture = Tempest::Test::Fixture->new;

    # Permanent fixtures owned by $fixture
    my $schema  = $fixture->schema;
    my $repo    = $fixture->repo;
    my $svn     = $fixture->svn_client;

    # Transient fixtures created by $fixture
    my $survey = $fixture->generate_survey(  # generates survey files
                            client_id => $client_id,
                            survey_id => $client_id,
                        );
    my $survey = $fixture->find_survey(
                            client_id => $client_id,
                            survey_id => $client_id,
                        );

    # Convenience functions
    my $rs = $fixture->rs('Client')->search( ... );

    my $svn_root      = $fixture->svn_root;
    my $svn_path      = $fixture->svn_path_to($client_id, $survey_id, ...);

    my $checkout_root = $fixture->checkout_root;
    my $checkout_path = $fixture->checkout_path_to($client_id, $survey_id, ...);


=head1 DESCRIPTION

Centralises management of various test fixtures.

Manages the dependencies between fixtures so that the various fixtures are
built and destroyed in the correct order, and to keep the fixtures themselves
unaware of each other.

=cut
