package Tempest::Test;

# This isn't strictly necessary, as we use Deployment::Debug by default, but is
# a nice safety fallback just in case we inadvertently target a real stomp
# message queue in testing.
BEGIN { $ENV{SD_TEMPEST_MOCKSTOMP} = 1; }

# Import SD::Test's sybbols and further down, re-export them.
use SD::Test;
use Import::Into;

use Path::Class;

use Log::Any::Adapter;
use Log::Any::Plugin;
use File::Temp;

my $keep_files = $ENV{TEMPEST_KEEP_FILES} // 0;

Log::Any::Adapter->set($ENV{TEMPEST_TEST_LOG_ADAPTER} // 'Test');
Log::Any::Plugin->add('Stringify');
Log::Any::Plugin->add('Levels', level =>
                            $ENV{TEMPEST_TEST_LOG_LEVEL} // 'warning');

use Log::Any qw($log);

use v5.14.1;

use parent 'Exporter';
our @EXPORT = (
    @SD::Test::EXPORT,
    qw($SRCDIR $LIBDIR $SCRIPTDIR $TESTDIR $CLEANUP_REPO)
);

# Figure out the INC dir we were loaded from which should be t/lib
sub find_our_inc_dir {
    return file(__FILE__)->dir->parent;
}

sub find_src_dir {
    my $dir = find_our_inc_dir;

    # Walk up through blib/lib or t/lib to find the source tree
    $dir = $dir->parent if $dir->dir_list(-1) eq 'lib';
    $dir = $dir->parent if $dir->dir_list(-1) eq 'blib';
    $dir = $dir->parent if $dir->dir_list(-1) eq 't';

    return $dir;
}

sub tempdir {
    return File::Temp::tempdir( CLEANUP => ! $keep_files );
}

our $SRCDIR    = find_src_dir()->resolve->absolute;
our $LIBDIR    = $SRCDIR->subdir("lib");
our $SCRIPTDIR = $SRCDIR->subdir("script");
our $TESTDIR   = $SRCDIR->subdir("t");
our $CLEANUP_REPO = 1;

sub import {
    # Set path to test config.
    $ENV{TEMPEST_CONFIG} = $TESTDIR->stringify;

    # Export our own sybbols
    shift->export_to_level(1);

    # As well as those exported by SD::Test
    SD::Test->import::into(1);
}

1;

__END__

=head1 NAME

Tempest::Test - Custom test module for Tempest

=head1 SYNOPSIS

    use lib 't/lib';
    use Tempest::Test;


=head1 DESCRIPTION

Tempest::Test does the following:

  * Turns on strict
  * Turns on warnings
  * Exports Test::Most's functions
  * Sets up a testing configuration
  * Sets up Tempest::Test::Log  (our extension of Log::Any::Test)

The testing configuration sets the appropriate environment variables
to point at the testing config.

=head1 LOG TESTS

    # Optionally
    BEGIN { $ENV{TEMPEST_TEST_LOG_LEVEL} = 'info' } # defaults to 'warning'

    use Tempest::Test;
    use Log::Any qw($log);

    # Now use any of the methods from Log::Any::Adapter::Test
    $log->clear;
    $log->empty_ok;
    $log->contains_ok;
    $log->msgs;
    # etc


=head1 VARIABLES

Tempest::Test exports from variables that prove useful during testing.

=head3 $SRCDIR

The absolute location of the top level source directory.

This is a Path::Class::Dir.

=head3 $LIBDIR

The absolute location of the lib directory.

This is a Path::Class::Dir.

=head3 $SCRIPTDIR

The absolute location of the script directory.

This is a Path::Class::Dir.

=head3 $TESTDIR

The absolute location of the t directory.

This is a Path::Class::Dir.

=head1 ACKNOWLEDGEMENTS

Blatantly copied from WS::Test. Thanks Schwern :)

=cut

