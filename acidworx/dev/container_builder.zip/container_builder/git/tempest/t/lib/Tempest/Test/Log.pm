package Tempest::Test::Log;
use base qw(Log::Any::Adapter::Test);
use Carp qw(croak);

#our @CARP_NOT = qw( Log::Any::Adapter Log::Any::Manager );

my %log_level;
{
    my $i = 0;
    $log_level{$_} = $i++ for Log::Any->logging_methods();
}

sub new {
    my $class = shift;
    my $self = bless {@_}, $class;
    $self->{level} = 'debug' unless defined $self->{level};
    local $Carp::CarpLevel = 2; # can't get @CARP_NOT to work (?)
    croak "Unknown logging level $self->{level}" unless exists $log_level{$self->{level}};
    return $self;
}

# All detection methods return true
#
foreach my $method ( Log::Any->detection_methods() ) {
    Log::Any::Adapter::Util::make_method($method, sub {
        my $self = shift;
        return $log_level{$self->{level}} <= $log_level{$method};
    } );
}

# All logging methods push onto msgs array
#
foreach my $method ( Log::Any->logging_methods() ) {
    my $super = *{ "Log::Any::Adapter::Test::$method" };
    Log::Any::Adapter::Util::make_method($method, sub {
            my ( $self, $msg ) = @_;
            return if $log_level{$self->{level}} > $log_level{$method};
            return $super->($self, $msg);
        }
    );
}

1;

=head1 NAME

Tempest::Test::Log - Log::Any::Test with log filtering

=head1 SYNOPSIS

    use Log::Any::Adapter;
    #Log::Any::Adapter->set('Test'); # this has been replaced
    Log::Any::Adapter->set('+Tempest::Test::Log', level => 'warning');
    use Log::Any qw($log);

=head1 DESCRIPTION

Adds log level filtering to Log::Any::Test

=cut

