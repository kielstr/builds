package Tempest::Test::Fixture::WebApp;

use Moose;
use namespace::autoclean;
extends 'Tempest::Test::Fixture';

use SD::Tempest::Configuration;
use Test::WWW::Mechanize::Catalyst;

use HTTP::Request::Common; # for POST
use JSON;

use Carp qw(croak);

sub BUILD {
    my ($self) = @_;
    my $config = SD::Tempest::Configuration->config;

    $self->database;    # make sure the database gets created

    $config->{repo}         = $self->svn_root;
    $config->{checkout}     = $self->checkout_root;

    my $base_path = $self->repo->base_path;

    my $export_root = $base_path->subdir('exports');
    $export_root->mkpath;
    $config->{export_root} = $export_root->stringify;

    # Override the LDAP user (for svn interaction)
    $config->{ldap}->{username} = (keys %{ $self->users })[0];
    $config->{ldap}->{password} = $self->users->{ $config->{ldap}->{username} };
}

#------------------------------------------------------------------------------

sub create_mech {
    my ($self) = @_;

    return Test::WWW::Mechanize::Catalyst->new(
            catalyst_app => 'SD::Tempest::WebApp'
        );
}

sub login {
    my ($self, $mech, $username, $password) = @_;

    $mech     //= $self->create_mech,
    $username //= (keys %{ $self->users })[0];
    $password //= $self->users->{$username};

    $mech->get('/login');
    $mech->submit_form(
            fields => {
                username => $username,
                password => $password,
            });
    croak 'login returned status ' . $mech->status
        unless $mech->status == 200;

    return $mech;
}

sub get_url {
    my ($self, $mech, $url) = @_;

    $mech->get($url);
    return $mech->status;
}

sub json_get {
    my ($self, $mech, $uri, $headers) = @_;

    $headers ||= {};
    my $data = {};

    my $req = GET ( $uri,
        'Content_Type' => 'text/json',
        'Accept'       => 'application/json',
        %$headers,
        'Content'      => encode_json( $data ),
    );

    $mech->request( $req );
}

sub json_post {
    my ($self, $mech, $uri, $headers, $data) = @_;

    $headers ||= {};
    $data ||= {};

    my $req = POST ( $uri,
        'Content_Type' => 'text/json',
        'Accept'       => 'application/json',
        %$headers,
        'Content'      => encode_json( $data ),
    );

    $mech->request( $req );
}

sub json_decode {
    my ($self, $mech) = @_;
    return decode_json($mech->content);
}

#------------------------------------------------------------------------------

# Modify _build_users to grab the users from the config file
sub _build_users {
    my ($self) = @_;

    my $config = SD::Tempest::Configuration->config;

    my %user_info =
        %{ $config->{authentication}->{realms}->{testing}->{store}->{users} };
    my $authorized_role = $config->{authorized_role};

    my %users;
    for my $username (keys %user_info) {
        my @roles = @{ $user_info{$username}->{roles} };
        next unless grep { $_ eq $authorized_role } @roles;

        $users{$username} = $user_info{$username}->{password};
    }

    return \%users;
}

__PACKAGE__->meta->make_immutable;

1;

