package SD::Docker::Build;

use strict;
use warnings;
use Moo;

use Function::Parameters qw( :strict );
use Log::Any qw( $log );
use feature 'say';
use Data::Dumper 'Dumper';

use File::Temp 'tempdir';
use Cpanel::JSON::XS;

use Try::Tiny;
use Capture::Tiny 'capture';
use Path::Tiny;

has temp_dir    => ( is => 'rw' );
has current_dir => ( is => 'rw' );
has svn_dest    => ( is => 'rw' );
has tar_file    => ( is => 'rw' );

# Checkout the repo to disk and record the location
#
# TODO: would be nice if this could support git also.
method _check_out_repo() {

    $log->info( 'Checking out the repo [' . $self->src_repo . '].' );

    my $svn_cmd           = '/usr/bin/svn';
    my $checkout_dest_dir = './svn_checkout';

    $self->temp_dir( tempdir( 'CLEANUP' => 1 ) );

    $self->svn_dest( path( $self->temp_dir . $checkout_dest_dir ) );

    chdir $self->temp_dir
      or $self->throw_error(
        'Failed to cd into the temp dir: ' . $self->temp_dir . ' ' . $! );

    my ( $stdout, $stderr, $exit ) = capture {
        system( $svn_cmd, ( 'checkout', $self->src_repo, $self->svn_dest ) );
    };

    $self->throw_error( 'Failed to check out files ' . $stderr )
      if $stderr;

    $log->info($stdout) if $self->debug and $stdout;

    $log->info('Done.');

}

# tar the repo checkout and record the file location.
method _tar_build_context() {

    my $tar_cmd      = '/bin/tar';
    my $tar_filename = 'build_context.tar';

    $self->tar_file( path( $self->temp_dir . '/' . $tar_filename ));

    $log->info( 'Building context tar file [' . $self->tar_file . '].' );

    chdir $self->svn_dest
      or
      $self->throw_error( 'Failed to cd into ' . $self->svn_dest . ' ' . $! );

    my ( $stdout, $stderr, $exit ) = capture {
        system $tar_cmd, ( 'cvf', $self->tar_file, '.' );
    };

    if ($stderr) {
        $self->throw_error( 'Failed to tar build context ' . $stderr );
    }

    $log->info($stdout) if $self->debug and $stdout;

    $log->info('Done.');
}

# Docker API build -- https://docs.docker.com/engine/api/v1.32/#operation/ImageBuild
#
# Send the tarball to Docker and have it build and tag the image.
# Docker

method build_img(%options) {

    $log->info('Building image.');

    $options{'dockerfile'} ||= 'Dockerfile';

    $options{'t'} ||= ( $self->docker_repo . '/'
          . join( ':', $self->image_name, $self->image_tag ) );

    $self->_check_out_repo;

    $self->_tar_build_context;

    my $tar_contents = $self->tar_file->slurp;

    chdir '/container_builder'
      or $self->throw_error( 'Failed to cd into /container_builder ' . $! );

    my $query_str =
      (     $self->docker_url
          . '//build?'
          . join( '&', map { join '=', $_, $options{$_} } keys %options ) );

    my $return = $self->user_agent->post(
        $query_str,
        'Content-Type' => 'application/x-tar',
        'Content'      => $tar_contents,
    );

    unlink $self->tar_file
      or $self->gen_warning( 'Failed to delete tar file ' . $self->tar_file );

    for my $return_line ( split /\n/, $return->content ) {
        my $resp_href;
        try {
            $resp_href = decode_json($return_line)
              or $self->throw_error(
                'Failed to parse JSON line [$return_line] - ' . $! );
        }
        catch {
            $self->gen_warning("Caught error: $_");
        };

        $self->error( $resp_href->{'message'} )
          if defined $resp_href->{'message'};
    }

    if ( $return->code == 500 ) {
        $self->gen_warning( $self->error )
          if $self->error;

        $self->throw_error( 'Server Error: ' . $return->code );
    }
    elsif ( $return->code == 400 ) {

        $self->gen_warning( $self->error )
          if $self->error;

        $self->throw_error( 'Bad parameter: ' . $return->code );

    }
    elsif ( $return->is_success ) {
        $log->info( $return->content )
          if $self->debug;
    }
    else {

        $self->gen_warning( $self->error )
          if $self->error;

        $self->throw_error( 'Unknown error: ' . $return->code );
    }
}

1;
