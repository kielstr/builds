package SD::Docker::Exception;

use strict;
use warnings;
use feature 'say';

use Moo;
use Function::Parameters qw( :strict );

extends 'Throwable::Error';

has type => ( is => 'ro' );
has msg  => ( is => 'ro' );

fun e() {
    if ( ref($_) eq 'SD::Docker::Exception' ) {
        return $_;
    }
    else {
        chomp;
        return SD::Docker::Exception->new( message => $_, type => 0 );
    }
}

1;
