package SD::Docker;

# Developed under v1.32
# https://docs.docker.com/engine/api/v1.32

# This class builds, tags and pushs a Docker images based on the options provided.

# options are
#    src_repo
#    docker_repo
#    image_name
#    image_tag
#    debug

use strict;
use warnings;

use Moo;
use Function::Parameters qw( :strict );

use LWP::UserAgent;
use LWP::Protocol::http::SocketUnixAlt;

use feature 'say';
use Data::Dumper 'Dumper';
use Carp;

use URI::Encode;
use MIME::Base64;

use Try::Tiny;
use Cpanel::JSON::XS;
use Log::Any qw( $log );

extends 'SD::Docker::Build', 'SD::Docker::Exception';

# Override LWP implementation of http communication
LWP::Protocol::implementor( http => 'LWP::Protocol::http::SocketUnixAlt' );

has user_agent => (
    is      => 'rw',
    default => sub {

        my $ua = LWP::UserAgent->new;
        $ua->agent("Tempest webbot v1");

        return $ua;
    },
);

has src_repo => ( is => 'ro', );

has docker_url => (
    is      => 'rw',
    default => 'http:/var/run/docker.sock',
);

has docker_repo => (
    is      => 'rw',
    default => 'http://localhost:5000',
);

has error => ( is => 'rw' );

has uri => (
    is      => 'rw',
    default => sub {
        return URI::Encode->new( { encode_reserved => 0 } );
    },
);

has debug => (
    is      => 'rw',
    default => 0,
);

has image_tag => ( is => 'rw' );

has image_name => ( is => 'rw' );

# Docker API push https://docs.docker.com/engine/api/v1.32/#operation/ImagePush
#
# Send of the image built.
# header X-Registry-Auth is required and can be used to secure the API access. See further details
# https://docs.docker.com/engine/api/v1.32/#section/Authentication

method push() {

    my $image = $self->uri->encode( $self->docker_repo . '/'
          . join( ':', $self->image_name, $self->image_tag ) );

    $log->info( 'Attempting to push ' . $image . ' to ' . $self->docker_repo );

    my $return = $self->user_agent->post(
        $self->docker_url . '/' . '/images/' . $image . '/push',
        'Content-Type'    => 'text/html',
        'X-Registry-Auth' => encode_base64(
            qq/
            {
                 "username": "string",
                  "password": "string",
                  "email": "string",
                  "serveraddress": "string"
            }
            /,
        ),
    );

# Docker returns a JSON object line by line. Think the idea is so you can add a hook/callback
# and stream realtime. We are just interested in any errors
    for my $return_line ( split /\n/, $return->content ) {
        my $resp_href;

        try {
            $resp_href = decode_json($return_line)
              or die "Failed to parse JSON line [$return_line] - $!";
        }
        catch {
            $self->gen_warning( 'Caught error: ' . $_ );
        };

        if ( defined $resp_href->{'error'} ) {
            $self->error( $resp_href->{'error'} );
        }
    }

    if ( $return->is_success ) {

        if ( $self->error ) {
            $self->throw_error( 'error: ' . $self->error );
        }
        else {
            $log->info( 'Image created, tagged and push to the registory' );
        }

    }
    else {
        $self->throw_error( $self->error . ': ' . $return->status_line );
    }
}

# Some helpers for error and warnings

method throw_error($message) {
    $log->error($message);

    SD::Docker::Exception->throw(
        {
            'type'    => 1,
            'message' => $message
        }
    );
}

method gen_warning($message) {
    carp $log->warn($message);
}

1;
