package SD::Tempest::WebApp::Role::Controller::REST::Component::Properties;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

requires 'component_mutate';

use Hash::Merge::Simple qw(merge);
use SD::Tempest::Exceptions;
use SD::Tempest::Form::Properties;
use Try::Tiny;

###############
## Action stubs

sub properties : Chained('component_mutate') PathPart('properties') Args(0) ActionClass('REST::ForBrowsers') {}

##############
## REST methods

sub properties_POST_html : Private {
    my ($self, $c) = @_;

    my $commutator = $c->stash->{commutator};
    my @deployments = $c->model('DB::Constraint::Deployment')->names;
    my $default_urls = $c->model('DB::Constraint::Deployment')->default_urls(
        $commutator->mutator->instance->survey->client->client_tag,
        $commutator->mutator->instance->survey->survey_tag,
        $commutator->component->id,
    );

    my $form = SD::Tempest::Form::Properties->new(
        user => $c->user->id,
        deployments => \@deployments,
        default_urls => $default_urls,
    );

    $c->stash->{template} = 'rest/component_properties.tt';
    $c->stash->{form} = $form;

    # Process form
    my $error;
    try {
        $form->process(
            item     => $c->stash->{'commutator'},
            params   => $c->request->params,
        );
    }
    catch {
        $error = $_;
    };
    return unless $error or $form->validated;

    my $msg_id;
    if ($error) {
        if (SD::Tempest::SVN::StaleCommit->caught($error)) {
            $msg_id = $c->set_error_msg('Properties update failed - please update from SVN and try again');
        }
        else {
            $msg_id = $c->set_error_msg("Properties update failed: $error");
        }
    }
    else {
        $msg_id = $c->set_status_msg('Updated component properties.yaml');
    }

    # the component in the mutator gets updates, need to update the one
    # in the stash too
	$c->stash->{ws_component} = $c->stash->{commutator}->component;

    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub properties_POST : Private {
    my ($self, $c) = @_;

    $c->detach('properties_POST_html') unless $c->request->data;

    my $data = $c->request->data;

    # We do not allow component_ids to be changed
    delete $data->{'component_id'};

    try {
        $c->stash->{commutator}->_commit_property_change(
            $c->user->id, $data,
            sub { $_[0] = merge( $_[0], $data ) }, # Aliasing, yuck, but that's what's required
            verb => 'Modify',
            entity_id => $c->stash->{commutator}->_entity_id,
            more_info => "Set properties.",
        );
        $self->status_ok( $c,
            entity => { status => 'Updated properties' } );
    } catch {
         $self->status_bad_request( $c,
             message => "Property set failed: $_" );
    };

}

1;
