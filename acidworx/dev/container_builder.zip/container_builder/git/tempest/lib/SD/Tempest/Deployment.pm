package SD::Tempest::Deployment;
use 5.14.1;
use Moose;
use namespace::autoclean;

with 'SD::Tempest::Role::Adaptor';

use SD::Tempest::Configuration;

has '+class' => (
    default => sub { SD::Tempest::Configuration->config->{deployment_class} // 'SD::Tempest::Deployment::Stomp' }
);

has _instance => (
    is      => 'ro',
    writer  => '_set_instance',
    does    => 'SD::Tempest::Role::Deployment',
    handles => 'SD::Tempest::Role::Deployment',
);

sub BUILD {
    my ($self, $args) = @_;
    # Set up our adapted instance
    $self->_load_adapted_class;
    $self->_set_instance( $self->_create_instance( $args ) );
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=head1 NAME

SD::Tempest::Deployment - adaptor for the various deployment methods

=cut

