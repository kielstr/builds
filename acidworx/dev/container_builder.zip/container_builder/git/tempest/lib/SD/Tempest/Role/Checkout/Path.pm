package SD::Tempest::Role::Checkout::Path;

use Moose::Role;
use namespace::autoclean;

has checkout_path => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::Dir',
    coerce      => 1,
    required    => 1,
);

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::Checkout::Path - checkout_path attribute

=head1 DESCRIPTION

Provides an checkout_path attribute.

checkout_path always points directly to the checkout directory of the consuming
class.

=cut
