package SD::Tempest::Configuration;
use 5.14.1;
use strict;
use warnings;

=head1 NAME

SD::Tempest::Configuration - Configuration file loading

=head1 SYNOPSIS

    # $config is a hash reference.
    my $config = SD::Tempest::Configuration->config;

=head1 DESCRIPTION

A module to manage the location, loading and merging of configuration
files.

This module somewhat emulates the behaviour that would be provided by
L<Catalyst::Plugin::ConfigLoader> except that it can be called from
outside the context of a Catalyst application (which is the right thing
to do once command-line utilities need access to configuration).

=cut

use Config::ZOMG;

use Carp qw( croak );
use Log::Any qw($log);
use Path::Class;

use namespace::autoclean;

=head1 CONSTANTS

See L</files>.

=cut

use constant {
    NAME                    => 'websurvey-tempest',
    CONFIG_ENV_KEY          => 'TEMPEST', # ZOMG appends '_CONFIG' to this ENV key
};

=head1 CLASS METHODS

=head2 condig

Delegate config loading to L<Config::ZOMG>.
Loads C<websurvey-tempest.*> and C<websurvey-tempest_local.*>
where * is any extension that L<Config::Any> handles.

Default path for config file is '/etc/websurvey-tempest'. 
Set ENV{TEMPEST_CONFIG} to override this path.

=cut

sub config {
    state $config = Config::ZOMG->new(
        name       => NAME,
        path       => '/etc/' . NAME, # Default place for config file
        env_lookup => [ CONFIG_ENV_KEY ],
        driver     => { General => { -ForceArray => 1 } },
    )->load;

    return $config;
}

=head2 bin_path( $package, $script_name )

Return the absolute path to the script C<$script_name> in the package C<$package>.

The bin path is configured via bin_path->{$package}.

=cut

sub bin_path {
   my ( $class, $package, $script ) = @_;

   croak("No package supplied") unless $package;
   croak("No script supplied") unless $script;

   my $config = $class->config;
   my $bin_path = $config->{bin_path}->{$package};
   croak("No bin_path defined in config for package $package") unless $bin_path;
   my $script_path = Path::Class::File->new($bin_path, $script);
   return $script_path->absolute;
}

=head2 build_path_to ( $config_key, @path_components )

Create a full path from $config->{$config_key} and the provided components.
Undefined and blank components are stripped out.

=cut

sub build_path_to {
    my $class = shift;
    my $config_key = shift;
    croak "Configuration key $config_key not found"
        unless $class->config->{$config_key};
    return join('/', $class->config->{$config_key},
        grep { defined $_ && length $_ } @_);
}

sub export_path_to {
    my $class = shift;
    return $class->build_path_to('export_root', @_);
}

sub checkout_path_to {
    my $class = shift;
    return $class->build_path_to('checkout', @_);
}

sub svn_path_to {
    my $class = shift;
    return $class->build_path_to('repo', @_);
}

1;

__END__

=head1 AUTHORS

=over

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2010 Strategic Data <http://www.strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.
