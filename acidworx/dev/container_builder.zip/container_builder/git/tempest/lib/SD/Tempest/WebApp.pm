package SD::Tempest::WebApp;
use Moose;

use namespace::autoclean;

use Catalyst::Runtime 5.80;

# Set flags and add plugins for the application
use Catalyst qw{
    Static::Simple
    Session
    Session::Store::DBIC
    Session::State::Cookie
    Authentication
    StatusMessage
};
extends 'Catalyst';

=head1 NAME

SD::Tempest::WebApp - Catalyst-based web application

=head1 DESCRIPTION

Tempest web user interface.

=cut

use Log::Any qw($log);

use SD::Tempest::Configuration ();

# Load our configuration, override some settings, and configure the
# whole thing.
__PACKAGE__->config( SD::Tempest::Configuration->config );

__PACKAGE__->log($log);

# Start the application up.  ...more or less...
__PACKAGE__->setup();

1;

__END__

=head1 SEE ALSO

L<SD::Tempest::WebApp::Controller::Root>, L<Catalyst>

=head1 AUTHORS

=over

=item Daniel Pittman <daniel@strategicdata.com.au>

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2011 Strategic Data <http://www.strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.
