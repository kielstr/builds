package SD::Tempest::Role::ClientID;

use Moose::Role;
use namespace::autoclean;

has client_id => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::ClientID',
    required    => 1,
);

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::ClientID - client_id attribute

=head1 DESCRIPTION

Provides an client_id attribute.

=cut
