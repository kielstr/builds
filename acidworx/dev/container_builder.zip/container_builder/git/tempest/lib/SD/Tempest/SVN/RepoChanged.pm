package SD::Tempest::SVN::RepoChanged;
use 5.16.0;
use warnings;

use Moose;
use namespace::autoclean;

use List::MoreUtils qw( any part );
use Method::Signatures;

use SD::Tempest::Configuration;
use SD::Tempest::Mutator::SurveyInstance;
use SD::Tempest::SVN::CommitInspector;
use Carp qw(croak);

use Log::Any qw($log);
use Try::Tiny;

with 'SD::Tempest::Role::Schema';

has commit => (
    is          => 'ro',
    isa         => 'SD::Tempest::SVN::CommitInspector',
    required    => 1,
);

has hostname => (
    is          => 'ro',
    isa         => 'Str',
    required    => 1,
);

has '+schema' => (
    required    => 1,
);

has tempest_username => (
    is          => 'ro',
    isa         => 'Str',
    default     => sub {
        SD::Tempest::Configuration->config->{ldap}->{username},
    },
);

method on_repo_changed() {

    my $rev = $self->commit->revision;
    $log->debug("Examining commit $rev from " . $self->hostname . $self->commit->svn_path);
    my $author = $self->commit->author // 'anonymous';
    if ($author eq $self->tempest_username) {
        $log->debug("Commit $rev is by tempest itself - skipping");
        return;
    }

    my @modified_survey_instances = $self->_modified_survey_instances;
    if (@modified_survey_instances == 0) {
        $log->debug("Commit $rev touches no surveys - skipping");
        return;
    }

    for (@modified_survey_instances) {
        my ($instance, @items) = @$_;

        my $tags = join('/', $instance->survey->client->client_tag,
                             $instance->survey->survey_tag);
        my $name = join('/', $tags, $instance->deployment->name);

        $log->debug("Updating $name to commit $rev");
        $instance->update({ revision => $rev });

        if (not any { $self->_modified_item_is_interesting($tags, $_) } @items) {
            $log->debug("Commit $rev has no interesting changes for $name");
            next;
        }

        $log->debug("Deploying $name at commit $rev");
        my $mutator = SD::Tempest::Mutator::SurveyInstance->new(
                instance => $instance,
                svn_client => $self->commit->svn_client,
            );
        $mutator->deploy($author);
    }
    $log->debug("Finished examining commit $rev");
}

method _modified_survey_instances() {

    my @modified_items = @{ $self->commit->modified_items };
    return unless @modified_items;

    my $hostname = $self->hostname;

    my $deployment_id = $self->rs('Constraint::Deployment')->search(
        {},
        {
            select   => 'deployment_id',
            order_by => 'deployment_id',
            rows     => 1,
        },
    )->single->deployment_id;

    # Rather than do a bunch of database queries here, just grab all the
    # survey instances that could possibly be relevant, which means:
    # - must be testing deployment
    # - must match the svn hostname
    # - must be at a revision less than the commit revision
    my $inst_rs = $self->rs('SurveyInstance')->search(
        {
            deployment_id => $deployment_id,
            svn_path => \"~ '://${hostname}[:./]'",
            revision => { '<' => $self->commit->revision },
        },
    );


    my @instances;

    # Now step through each candidate survey instance and grab out all the
    # modified items which belong to it.
    while (my $instance = $inst_rs->next) {

        my $path = $instance->svn_path;
        my $root;
        try {
            $root = $self->commit->svn_client->_svn_info($path)->{repository}->{root};
        }
        catch {
            $log->debug($_);
        };
        next if ! defined $root;
        $path =~ s{^$root}{};
        $path =~ s{/*$}{/}; # ensure there is a single trailing slash, so that
                            # we don't inadvertently match longer paths with the
                            # same initial substring
        my $path_re = qr{^$path};

        # Partition @modified_items into [ non-matching, matching ]
        my ($non_matching, $matching) =
            part { $_->{path} =~ $path_re } @modified_items;

        if ($matching) {
            push(@instances, [ $instance, @$matching ]);
        }

        # Keep only the non-matching items
        last unless $non_matching;
        @modified_items = @$non_matching;
    }

    return @instances;
}

method _modified_item_is_interesting ($tags, $item) {

    # Skip anything modified/created in "./admin" for the instance
    # Assumes typical svn directory structure:
    #   client_tag/survey_tag/optional_component_tag/admin
    # TODO: - "admin" is currently hard-coded.
    return if $item->{path} =~ m!$tags/(?:[^/]*/)?admin!;

    # TODO: Previously we skipped dir/M which was locks/unlocks, and dir/A
    #       unless it was a copy/move. Need to check if either of these still
    #       hold.

    return 1;
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::SVN::RepoChanged - handle repo changed notification

=head1 SYNOPSIS

    my $commit = SD::Tempest:SVN::CommitInspector->new( ... );
    my $rc = SD::Tempest::SVN::RepoChanged->new(
        commit => $commit,
        hostname => $repo_hostname,
        schema => $schema,
    );

  $rc->on_repo_changed;

=head1 DESCRIPTION

Inspects the commit, and triggers any necessary database updates and
deployments.

The following rules are applied to get a list of affected survey instances:

=over

=item

If the commit is caused by tempest itself, it is ignored.

=item

The hostname and the modified items list are matched up against survey
instances in the database to get a list of affected survey instances.

=item

Any survey instances whose revision is not less that the current commit are
excluded (this indicates the commit in question has already been processed).

=item

Any survey instances with only uninterested modifications are skipped.

=back

For each affected survey instance, the base deployment revision is updated to
that of the commit, and the instance is deployed.


=head1 METHODS

=head2 new

Parameters

=over

=item commit

An SD::Tempest::SVN::CommitInspector object.

=item hostname

The hostname of the svn repo that send the commit notification.

=item schema

An SD::Tempest::Schema object.

=back

=head2 on_repo_changed

Handles the repo change as per the description.

=cut
