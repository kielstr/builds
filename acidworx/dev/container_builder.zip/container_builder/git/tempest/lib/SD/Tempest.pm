package SD::Tempest;
use warnings;
use strict;

# We target strategic-perl, so make it obvious we want a newish perl version
use 5.16.0;

use version 0.77;  our $VERSION = qv('v205.03');

1;

__END__

=pod

=head1 NAME

SD::Tempest - Version and Author information for Tempest project

=head1 DESCRIPTION

The goal of Tempest is to provide the libraries and web based UI
to easy the distribution of survey content to the pools of C<WebSurvey>
nodes.

Tempest also includes UI around WebSurvey tools, such as Y2P, data export
session management and new survey creation. At some point in the (near?)
future some of this functionality is to be split off into another project
(Currently dubbed C<Lava Tornado>).

=head1 VERSION NUMBERING

This module only provides version numbers for the tempest project.
We want to keep versioning consistent between the code and its Debian
package number.

This module is to use version numbers (as vstrings) that match \d+\.\d+
The Debian packaging uses version numbers that match \d+-\d+
There is code in our C<Makefile.PL> that checks that these two are consistent.

Nominally, the RHS digits are for 'minor' or 'bug fix, no doc change' revisions
While the LHS digits should be incremented for anything else.

=head1 SEE ALSO

L<SD::Tempest::WebApp>

=head1 AUTHORS

=over

=item Daniel Pittman <daniel@strategicdata.com.au>

=item Alex Peters <alex.peters@strategicdata.com.au>

=item Russell Jenkins <russell.jenkins@strategicdata.com.au>

=item Josh Heumann <josh.heumann@strategicdata.com.au>

=item Stephen Thirlwall <stephen.thirlwall@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2011 Strategic Data <http://www.strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.

=cut
