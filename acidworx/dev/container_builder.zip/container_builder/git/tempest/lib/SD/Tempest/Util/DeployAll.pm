package SD::Tempest::Util::DeployAll;
use 5.16.0;
use Moose;
use namespace::autoclean;

with qw(
    SD::Tempest::Role::Schema
    SD::Tempest::Role::SVN::Client
);

use Method::Signatures;

use MooseX::StrictConstructor;
use Data::Dumper::Concise;

use SD::Tempest::Configuration;
use SD::Tempest::Mutator::Component;
use SD::Tempest::Mutator::SurveyInstance;
use SD::Tempest::SVN::Client;

use Log::Any qw( $log );

has dry_run => (
    is          => 'ro',
    isa         => 'Bool',
    default     => 1,
);

has config => (
    is          => 'ro',
    isa         => 'HashRef',
    lazy        => 1,
    default     => sub { SD::Tempest::Configuration->config },
);

has user => (
    is          => 'ro',
    isa         => 'Str',
    lazy        => 1,
    default     => sub { $ENV{USER} },
);

has '+schema' => (
    lazy        => 1,
    default     => method () {
        SD::Tempest::Schema->connect($self->config->{database})
    },
);

has '+svn_client' => (
    lazy        => 1,
    default     => method () {
        SD::Tempest::SVN::Client->new(%{ $self->config->{ldap} });
    },
);

method deploy_all() {

    if ($self->dry_run) {
        $self->config->{deployment_class} = 'SD::Tempest::Deployment::Debug';
    }

    # Find all active instances
    my $rs = $self->schema->resultset('SurveyInstance')->search(
        {
            inactive => [ undef, { '!=' => 1 } ],
        },
        {
            prefetch => [{ 'survey' => 'client' },
                         { 'instance_generation' => 'generation' },
                         'deployment'],
            order_by => [qw( me.deployment_id client_tag survey_tag )],
        }
    );

    while (my $instance = $rs->next ) {

        my $mutator = SD::Tempest::Mutator::SurveyInstance->new(
            svn_client => $self->svn_client,
            instance   => $instance,
        );
        $log->trace(Deploying   => $instance->survey->survey_tag,
                    to          => $instance->deployment->name,
                    for         => $instance->survey->client->client_tag,
        );
        $mutator->deploy($self->user);
    }
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=head1 NAME

SD::Tempest::Util::DeployAll - deploy all surveys from database

=cut

