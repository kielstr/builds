package SD::Tempest::DeploymentHandler;
use Moose;
use namespace::autoclean;

use feature 'say';

use SD::Tempest::Configuration ();
use SD::Tempest::Schema ();

use DBIx::Class::DeploymentHandler ();
use File::ShareDir ();
use File::Temp qw( tempdir );
use Try::Tiny;

has schema => (
    is => 'ro',
    isa => 'SD::Tempest::Schema',
    lazy_build => 1,
);

sub _build_schema {
    my $self = shift;
    my $config = SD::Tempest::Configuration->config;
    my $schema;
    try {
       $schema = SD::Tempest::Schema->connect( $config->{'database'} );
    } catch {
        warn "In Catch..";
        my $error = $_;
        if ( $error =~ m/database \".+\" does not exist/ ) {
            # Database does not exist, try to create it
            $self->_create_db( $config->{'database'}->{'dbname'} );
            $schema = SD::Tempest::Schema->connect( $config->{'database'} );
        } else {
            die $error;
        }
    };
    return $schema;
}

has dh => (
    is => 'ro',
    isa => 'DBIx::Class::DeploymentHandler',
    lazy_build => 1,
    handles => {
        upgrade => 'upgrade',
        current_version => 'database_version',
    },
);

sub _build_dh {
    my $self = shift;
    return DBIx::Class::DeploymentHandler->new({
        schema           => $self->schema,
        script_directory => $self->script_directory,
        databases        => 'PostgreSQL',
        quiet            => $self->quiet,
        force_overwrite  => $self->force,
    });
}

has script_directory => (
    is => 'ro',
    isa => 'Str',
    lazy_build => 1,
);

sub _build_script_directory {
    my $self = shift;
    return $self->testing ? tempdir( CLEANUP => 1)
                          : File::ShareDir::module_dir(__PACKAGE__);
}

has testing => (
    is      => 'ro',
    isa     => 'Bool',
    default => sub { ! ! $ENV{HARNESS_ACTIVE} },
);

has [qw/force quiet drop create/] => (
    is      => 'ro',
    isa     => 'Bool',
    default => 0,
);

sub generate_meta {
    my $self = shift;
    $self->dh->prepare_install;
}

sub install {
    my $self = shift;

    # get our database name
    my $database;
    try {
        my $cols = $self->schema->storage->dbh_do(
            sub {
                my ($storage, $dbh) = @_;
                $dbh->selectcol_arrayref("SELECT current_database()");
            }
        );
        $database = $cols->[0];
    };

    my $config = SD::Tempest::Configuration->config;
    $database ||= $config->{database}->{dbname};
    $database .= "_$$"
        if ($config->{environment} && ($config->{environment} eq 'testing'));
    die "Can not determine database name" unless $database;

    if ( $self->drop ) {
        # Disconnect the db connection
        $self->schema->storage->disconnect();
        say "# Dropping $database in 5 seconds";
        sleep(5);
        system( 'dropdb', $database );
    }
    if ( $self->drop || $self->create ) {
        $self->_create_db($database);
    }

    # In testing, Shhh up the NOTICE on primary keys
    $self->schema->storage->dbh->do("SET client_min_messages TO 'WARNING'")
      if $self->quiet;
    $self->dh->install();
    # re-enable notices
    $self->schema->storage->dbh->do("RESET client_min_messages")
      if $self->quiet;

    # Populate constraint tables
    # Needs to be done here, not as a DH deployment hook, as we need it in testing.
    foreach my $source_moniker ( sort $self->schema->sources ) {
        next unless $self->schema->class($source_moniker)->can('default_values');
        $self->schema->populate($source_moniker,
            $self->schema->class($source_moniker)->default_values
        );
    }

};

sub _create_db {
    my ( $self, $database ) = @_;

    # Create the database in we are in testing
    say STDERR "# Deploying database $database ..";
    my $config = SD::Tempest::Configuration->config;

    # Always use utf8 encoding. Always.
    my @createdb_args = ('--encoding=utf8');

    # Configure host
    if ( exists $config->{database}->{dbhost}
        && defined $config->{database}->{dbhost} )
    {
        push @createdb_args, '--host=' . $config->{database}->{dbhost};
    }

    # Configure user
    if ( exists $config->{database}->{user} ) {
        push @createdb_args, '--username=' . $config->{database}->{user};
    }

    # Configure port
	my $port = exists $config->{database}->{port} ?
	    $config->{database}->{port} :
	    '5432'; # default postgresql port
	push @createdb_args, "--port=$port";

    # Place password in ENV
    $ENV{PGPASSWORD} = $config->{database}->{password}
      if exists $config->{database}->{password};

    system( 'createdb', @createdb_args, $database );
}

sub generate_upgrade {
    my $self = shift;
    $self->generate_meta;
    $self->dh->prepare_upgrade;
}

sub create_diagram {
    my $self = shift;
    my $trans = SQL::Translator->new(
        parser => 'SQL::Translator::Parser::DBIx::Class',
        parser_args => { dbic_schema => $self->schema },
        producer => 'GraphViz',
        producer_args => {
            out_file => $self->script_directory . '/diagram.png',
            node => {
                fillcolor => 'AntiqueWhite',
            },
            show_constraints => 1,
            show_datatypes => 1,
            show_sizes => 1,
            skip_tables => [qw/ dbix_class_deploymenthandler_versions /],
            layout => 'neato',
            #directed => 0,
        } );

    $trans->translate;
}

__PACKAGE__->meta->make_immutable();
1;

__END__

=pod

=head1 NAME

SD::Tempest::DeploymentHandler - DeploymentHandler utility methods for Tempest

=head1 METHODS

=head2 generate_meta

Generates the DeploymentHandler baselines and schema sql

=head2 generate_upgrade

Generates the DeploymentHandler baselines and migration paths for the schema

=head2 install

Install schema into a new database.

=head2 current_version

Returns the current database version

=cut


