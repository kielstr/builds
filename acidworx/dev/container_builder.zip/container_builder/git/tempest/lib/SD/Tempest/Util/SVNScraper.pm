package SD::Tempest::Util::SVNScraper;
use 5.16.0;
use Moose;
use namespace::autoclean;

use SD::Tempest::SVN::Client;
with 'SD::Tempest::Role::Schema';

use MooseX::StrictConstructor;
use XML::Simple;

use SD::Tempest::Configuration;
use Method::Signatures;

use Log::Any qw($log);

has config => (
    is          => 'ro',
    isa         => 'HashRef',
    lazy        => 1,
    default     => sub { SD::Tempest::Configuration->config },
);

has '+schema' => (
    lazy        => 1,
    default     => method () {
        SD::Tempest::Schema->connect($self->config->{database})
    },
);

has svn_path => (
    is          => 'ro',
    isa         => 'Str',
    lazy_build  => 1,
);

has generation => (
    is          => 'ro',
    isa         => 'Str',
    lazy        => 1,
    default     => method () {
        $self->config->{ws_platform}->{generation}
    },
);

has svn_client => (
    is          => 'ro',
    isa         => 'SD::Tempest::SVN::Client',
    lazy        => 1,
    default     => method () { SD::Tempest::SVN::Client->new(
                        %{ $self->config->{ldap} } ) },
);

method populate_tables() {
    my $info = $self->_get_repo_info;
    $self->_update_database($info);
}

method relocate_inactive_surveys (:$from = 'inactive', :$to = 'development') {
    my $rs = $self->schema->resultset('SurveyInstance')->search(
        {
            svn_path => { like => $self->svn_path . "/$from/%" },
        },
        {
            prefetch => { survey => 'client' },
        },
    );

    while (my $si = $rs->next) {
        my $old_path = $si->svn_path;
        my $new_path = $old_path =~ s{/$from/}{/$to/}r;
        my $survey = $si->survey->survey_tag;
        my $client = $si->survey->client->client_tag;

        my $message = "Relocating inactive $client/$survey to development";
        $log->notice("$message: $old_path -> $new_path");

        my $revision = $self->svn_client->move($old_path, $new_path, $message);
        $si->update({ revision => $revision, svn_path => $new_path });
    }
}

method _get_repo_info() {
    my $info;
    my $path = $self->svn_path;

    # Create this sort of structure:
    #   $client:
    #       $survey:
    #           $deployment:
    #               revision: $revision
    #               date:     $revision_date
    #               svn_path: $svn_path
    #               inactive: $inactive

    for my $deployment ($self->_dir_list($path)) {
        my $dname = $deployment->{name};
        my $dpath = "$path/$dname"; # this needs to come before the remapping

        my ($new_dname, $inactive) = _remap_deployment($dname);

        for my $client ($self->_dir_list($dpath)) {
            my $cname = $client->{name};
            my $cpath = "$dpath/$cname";

            for my $survey ($self->_dir_list($cpath)) {
                my $sname = $survey->{name};
                my $spath = "$cpath/$sname";

                # Only create the client hash if we've actually got surveys
                $info->{$cname}->{$sname}->{$new_dname} = {
                    revision => $survey->{revision},
                    date     => $survey->{date},
                    svn_path => $spath,
                    inactive => $inactive,
                };
            }
        }
    }
    return $info;
}

method _update_database($info) {

    my $schema = $self->schema;

    # Grab these ahead of time to save repeated lookups
    # (why? I dunno, I just don't like looking at those repeated lookups...)
    my $generation_id = $schema->resultset('Constraint::Generation')
                               ->find({name => $self->generation})
                               ->generation_id;

    my %deployment_id = map { $_->name => $_->id }
                              $schema->resultset('Constraint::Deployment')->all;

    # Don't leave behind a partially populated databate.
    $schema->txn_do(sub {

        while (my ($client_tag, $cinfo) = each %$info) {
            # Don't do any create-or-update business here.
            # We don't want to be running this twice, so if anything already
            # exists, die die die.
            my $client = $schema->resultset('Client')->create({
                client_tag => $client_tag,
            });

            while (my ($survey_tag, $sinfo) = each %$cinfo) {

                my $survey = $client->add_to_surveys({
                    survey_tag => $survey_tag,
                });

                while (my ($deployment_tag, $dinfo) = each %$sinfo) {

                    my $instance = $survey->add_to_instances({
                        deployment_id => $deployment_id{$deployment_tag},
                        instance_generation => {
                            generation_id => $generation_id,
                        },
                        svn_path      => $dinfo->{svn_path},
                        revision      => $dinfo->{revision},
                        timestamp_utc => $dinfo->{date},
                        inactive      => $dinfo->{inactive},
                    });
                }
            }
        }
    });
}

method _dir_list ($path) {
    my $items = $self->svn_client->list($path, 'HEAD');

    return
        map { {
            name => $_,
            revision => $items->{$_}->{commit}->{revision},
            date => $items->{$_}->{commit}->{date},
        } }
        grep { $items->{$_}->{kind} eq 'dir' }
        keys %$items
        ;
}

func _remap_deployment ($deployment_name) {
    if ($deployment_name eq 'inactive') {
        # inactive is deactivated testing
        return ( testing => 1 );
    }
    if ($deployment_name eq 'to_be_archived') {
        # to_be_archived is deactivated production
        return ( production => 1 );
    }
    if ($deployment_name eq 'development') {
        # development is now called testing
        return ( testing => 0 );
    }
    return ( $deployment_name => 0 );
}

method _build_svn_path() {

    # The default repo config entry will end with 'development'
    # We don't want this.
    my $repo = $self->config->{repo};
    $repo =~ s{/?development/?$}{};

    return $repo;
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::Util::SVNScraper - populate tags tables from pre-tags table SVN

=head1 SYNOPSIS

    use SD::Tempest::Util::SVNScraper;

    my $scraper = SD::Tempest::Util::SVNScraper->new;
    $scraper->populate_tables;

=head1 DESCRIPTION

Walks through the SVN repo tree and populates tags table tables.

Expects the repo to be structured as

    $root/$deployment/$client/$survey/...

The config->{repo} path may or may not end with 'development'.
If it does, the 'development' portion is stripped before walking the repo.

=cut
