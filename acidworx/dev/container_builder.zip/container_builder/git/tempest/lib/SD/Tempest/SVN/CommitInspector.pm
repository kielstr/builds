package SD::Tempest::SVN::CommitInspector;
use 5.14.1;
use Moose;
use namespace::autoclean;

use Carp qw(croak);
use Log::Any qw($log);
use Method::Signatures;
use MooseX::StrictConstructor;

use SD::Tempest::Configuration ();
use SD::Tempest::SVN::Client ();

with 'SD::Tempest::Role::SVN';

has revision => (
    is          => 'ro',
    required    => 1,
);

has info => (
    is          => 'ro',
    init_arg    => undef,
    lazy        => 1,
    default     => method () {
        # The actual svn command here is:
        #  svn log --xml -v -r $revision $svn_path
        $self->svn_client->revision_info($self->svn_path, $self->revision)
    },
);

has date => (
    is          => 'ro',
    init_arg    => undef,
    lazy        => 1,
    default     => method () {
        $self->svn_client->parse_datetime($self->info->{date})
    },
);

has modified_items => (
    is          => 'ro',
    init_arg    => undef,
    lazy_build  => 1,
);

sub BUILD {
    shift->info; # die here if revision_info is bad, rather than in accessors
}

method author() {
    return $self->info->{author};
}

method msg() {
    return $self->info->{msg};
}

method _build_modified_items() {
    return [
        sort { $a->{action} cmp $b->{action} ||
               $a->{kind}   cmp $b->{kind}   ||
               $a->{path}   cmp $b->{path} }
        map { {
            action => $_->{action},
            kind   => $_->{kind},
            path   => $_->{content},
        } }
        @{ $self->info->{paths}->{path} } ];
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::SVN::CommitInspector - inspect an individual SVN commit

=head1 SYNOPSIS

    my $inspector = SD::Tempest::SVN::CommitInspector->new(
                        svn_client => $svn_client,
                        svn_path   => $repo_root,
                        revision   => $revision,
                    );

    my $author = $inspector->author;
    my $date = $inspector->date; # DateTime object
    my $msg  = $inspector->msg;

    for my $item (@{ $inspector->modified_items }) {
        say 'action: ', $item->{action};
        say 'kind:   ', $item->{kind};
        say 'path:   ', $item->{path};
    }

=head1 DESCRIPTION

Presents an OO interface to an individual svn commit.
The commit information is taken from:

        svn log --xml -v -r $revision $svn_path

=head1 METHODS

=head2 new( %args )

Arguments:

=over

=item svn_client

SD::Tempest::SVN::Client object

=item svn_path

Root path / uri of svn repo. Dies if this is not a valid path.

=item revision

The revision id of the commit. Typically an integer, but may be any valid svn
revision id. Dies if this is not a valid revision.

=back

=head1 ATTRIBUTES

=head2 author

The author of the commmit.

=head2 date

The timestamp of the commit as a DateTime object.

=head2 msg

The commit message.

=head2 modified_items

ArrayRef of modified items in the commit. Each item is a hash with the following keys:

=over

=item action

One of: A D M (more?)

(Add, Delete, Modify)

=item kind

One of: file dir (more?)

=item path

Repository-relative path to the modified item.

eg. /development/stratdat/test-survey/

=cut
