package SD::Tempest::HealthCheck::Subversion;
use 5.16.0;
use warnings;

use SD::Tempest::Configuration;
use SD::Tempest::SVN::Client;

sub check {
    my $config = SD::Tempest::Configuration->config;
    my $svn = SD::Tempest::SVN::Client->new(%{ $config->{ldap} });

    # This will die if it fails, and return true if not.
    $svn->health_check($config->{repo} . '/health-check');

    # Healthcheck.pm expects no return on success.
    return;
}

1;
