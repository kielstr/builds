package SD::Tempest::WebApp::Role::Controller::REST::Survey;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use Try::Tiny;

use SD::RandomToken;
use SD::Tempest::Form::Survey;
use SD::Tempest::Mutator::SurveyInstance;

has survey_form => (
    is  => 'ro',
    isa => 'SD::Tempest::Form::Survey',
    default => sub { SD::Tempest::Form::Survey->new },
);

#############
# Scaffolding

sub survey_base : Chained PathPart(';') CaptureArgs(0) {}

sub survey_find : Chained('survey_base') PathPart('') CaptureArgs(1) {
    my ($self, $c, $tag) = @_;

    $c->stash->{'survey_id'} = $tag;

    # Fetch it from the DB
    $c->stash->{'survey'} = $c->stash->{client}->search_related( 'surveys',
        { 'survey_tag' => $tag }
    )->single;           

    unless ( $c->stash->{'survey'} ) {
        $self->status_not_found( $c,
            message => 'Survey not found',
        );
        $c->detach('end');
    }

    push @{ $c->stash->{'nav'} }, {
        uri  => $c->uri_for( $c->stash->{'nav'}->[-1]->{uri}->path, $tag, 'instance' ),
        text => "Survey $tag",
    };
}

##############
# Action stubs

sub survey : Chained('survey_base') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

sub survey_single : Chained('survey_find') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

##############
# REST methods

sub survey_GET : Private { # Return list of surveys
    my ($self, $c) = @_;
    
    return $self->status_ok( $c,
        entity => { surveys => [ map { { $_->get_inflated_columns } } 
                                   $c->stash->{'client'}->surveys->all ] }
    );
}

sub survey_POST_html : Private {  # Add client via form
    my ($self, $c) = @_;

    $c->stash->{'template'} = 'rest/survey_new.tt';

    # Add form and empty survey object to the stash
    $c->stash->{form} = $self->survey_form;
    $c->stash->{survey} = $c->model('DB::Survey')->new_result({
        client_id => $c->stash->{'client'}->client_id });

    # Process form
    return unless $self->survey_form->process(
        item   => $c->stash->{survey},
        params => $c->request->params,
    );

    for (qw( survey_title survey_pages )) {
        $c->stash->{$_} = $self->survey_form->field($_)->value;
    }

    $c->forward('create_default_component');

    my $msg_id = $c->set_status_msg(
        sprintf "Survey '%s' created.", $c->stash->{survey}->survey_tag
    );
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub survey_POST : Private { # Add survey
    my ($self, $c) = @_;

    $c->detach('survey_POST_html') unless $c->request->data;
    my $new_survey_tag = $c->request->data->{'survey_tag'};

    return $self->status_bad_request( $c,
        message => 'No survey_tag defined in request' )
        unless defined $new_survey_tag;

    return $self->status_bad_request( $c,
        message => 'Not a valid survey_tag')
        unless $new_survey_tag =~ /^[a-z][a-z0-9\-]*$/;

    try {

        my $survey = $c->model('DB::survey')->find_or_new({
            client_id  => $c->stash->{client}->client_id,
            survey_tag => $new_survey_tag, 
        });

        # Return 201 if that was a new client
        if ( ! $survey->in_storage ) {
            $survey->insert;
            $survey->discard_changes; # reload from db
            $c->stash->{survey} = $survey; # Stash for component creation
            $c->forward('create_default_component');
            $self->status_created( $c,
                location => join('/', $c->request->uri, $new_survey_tag),
                entity   => {
                    status => 'created',
                    survey => { $survey->get_inflated_columns },
                },
            );

        } else {

            # Otherwise return 'found'
            $self->status_found( $c,
                entity   => {
                    status => 'found',
                    survey => { $survey->get_inflated_columns },
                },
            );
        }

    } catch {
        $self->status_bad_request( $c,
            message => "Can't create new survey: $_ ");
    };

}

sub create_default_component : Private {
    my ($self, $c) = @_;

    # In the *future*, components won't exist, but for now, we need to
    # deal with them. Creating a new survey implies creating the default
    # component.
    #
    # Create DB entry for development instance
    my $deployment = $c->model('DB::Constraint::Deployment')->base_deployment;
    my $generation = $c->model('DB::Constraint::Generation')->search(
        { name => $c->config->{ws_platform}{generation} })->single;
    my $instance = $c->model('DB::SurveyInstance')->create({
        survey_id     => $c->stash->{survey}->survey_id,
        deployment_id => $deployment->deployment_id,
        instance_generation => {
            generation_id => $generation->generation_id,
        },
        revision      => 0,
        timestamp_utc => \'NOW()',
        svn_path      => join("/",
            $c->config->{repo},
            $c->stash->{client}->client_tag,
            $c->stash->{survey}->survey_tag
        ),
    });
    # And the actual content
    my $mutator = SD::Tempest::Mutator::SurveyInstance->new(
        instance   => $instance,
        svn_client => $c->model('SVNClient'),
    );
    $mutator->create_component(
        id     => SD::RandomToken->new,
        name   => '', # default component
        title  => $c->stash->{survey_title} // 'Default survey title',
        pages  => $c->stash->{survey_pages} // 3,
        user   => $c->stash->{user} // 'sd-dev-tempest',
        urls   => $c->model('DB::Constraint::Deployment')->default_urls(
            $c->stash->{client}->client_tag,
            $c->stash->{survey}->survey_tag,
        ),
    );
    $mutator->deploy($c->user->id);
}

sub survey_single_GET : Private { # View survey
    my ($self, $c) = @_;

    return $self->status_ok( $c,
        entity => { survey => { $c->stash->{'survey'}->get_inflated_columns } }
    );
}

1;

