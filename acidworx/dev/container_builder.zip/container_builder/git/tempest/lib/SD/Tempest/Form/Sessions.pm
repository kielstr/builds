package SD::Tempest::Form::Sessions;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler';

use namespace::autoclean;

# Do we need/want these?
#has '+widget_wrapper' => ( default => 'Table' );
#has '+widget_form' => ( default => 'Table' );

has sessions => (
    is          => 'ro',
    isa         => 'ArrayRef',
    required    => 1,
);

has_field session => (
    type            => 'Select',
    label           => 'YAML File',
    options_method  => sub {  map { $_ => $_ } @{ shift->form->sessions } },
    required        => 1,
);

has_field submit => (
    type        => 'Submit',
    value       => 'Push Session',
);

sub selected_session {
    my ($self) = @_;
    return $self->field('session')->value;
}

sub BUILD {
    my $self = shift;
    if (@{ $self->sessions } > 1) {
        # Only force the user to choose if there's more than one to choose from
        $self->field('session')->empty_select('--Choose a session--');
    }
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::Form::Export - select export format and submit/cancel

=cut
