package SD::Tempest::Role::Schema;

use Moose::Role;
use namespace::autoclean;

use Carp qw( confess );

use SD::Tempest::Configuration;
use SD::Tempest::Schema;

has schema => (
    is          => 'ro',
    isa         => 'SD::Tempest::Schema',

    # Note: Don't connect a new schema in a builder/default method, let the
    #       caller provide one. Otherwise we end up with a ton of schema
    #       connections to the database.

    # Note: We don't need to force this parameter. Some consuming classes only
    #       use the schema as a default initialiser.
);

sub rs {
    my ($self, $resultset_name) = @_;
    my $schema = $self->schema
        or confess('schema attribute not defined');
    return $self->schema->resultset($resultset_name);
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::Schema - Role to add a schema attribute.

=head1 ATTRIBUTES

=head2 schema

A connected SD::Tempest::Schema object.

=head1 METHODS

=head2 rs ( $name )

Shorthand for $self->schema->resultset($name)

=cut
