package SD::Tempest::MooseTypes;

=head1 NAME

SD::Tempest::MooseTypes - Custom Moose data type declarations

=head1 DESCRIPTION

Definitions of Moose data types in a central location to assist changes
in validation, and to enable fancy things like coercion (e.g. passing a
path string to an object and having it store as a L<Path::Class::Dir>
instance).

=cut

use strict;
use warnings;
use Moose::Util::TypeConstraints;
use namespace::autoclean;

use Path::Class::Dir ();
use Path::Class::File ();
use URI ();

subtype 'SD::Tempest::MooseTypes::Dir'
    => as class_type('Path::Class::Dir');
coerce 'SD::Tempest::MooseTypes::Dir'
    => from 'Str'
        => via { Path::Class::Dir->new($_)->absolute };

subtype 'SD::Tempest::MooseTypes::File'
    => as class_type('Path::Class::File');
coerce 'SD::Tempest::MooseTypes::File'
    => from 'Str'
        => via { Path::Class::File->new($_)->absolute };

subtype 'SD::Tempest::MooseTypes::URI'
    => as class_type('URI');
coerce 'SD::Tempest::MooseTypes::URI'
    => from 'Str'
        => via { URI->new($_) };

subtype 'SD::Tempest::MooseTypes::OptionalFile'
    => as 'Str'
    => where { -f or not -e }
    => message { "$_ exists but is not a file" };

# Do we want to be hitting the database for this? I suspect not.
#subtype 'SD::Tempest::MooseTypes::DeploymentID'
#    => as 'Str'
#    => where { #TODO: use the Constraint::Deployment table here (or not!)
#        $_ eq 'development'
#        or $_ eq 'staging'
#        or $_ eq 'production' }
#    => message { "$_ is not a valid deployment ID" };

subtype 'SD::Tempest::MooseTypes::ClientID'
    => as 'Str';
subtype 'SD::Tempest::MooseTypes::SurveyID'
    => as 'Str';
subtype 'SD::Tempest::MooseTypes::SVNUsername'
    => as 'Str';
subtype 'SD::Tempest::MooseTypes::SVNPassword'
    => as 'Str';

1;

__END__

=head1 AUTHORS

=over

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2009 Strategic Data <http://www.strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.

