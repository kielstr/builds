package SD::Tempest::Role::Deployment;
use Moose::Role;
use namespace::autoclean;

requires qw{ deploy dbsync dbrebuild export };

=head2 instance

The L<SD::Tempest::Schema::Result::SurveyInstance> to be 'deployed'.

=cut

has instance => (
    is          => 'ro',
    isa         => 'SD::Tempest::Schema::Result::SurveyInstance',
    required    => 1,
);

=head2 component

The L<SD::Tempest::Component> to be 'deployed'.

=cut

has component => (
    is          => 'ro',
    isa         => 'SD::Tempest::Component',
    writer      => '_set_component',
    required    => 1,
);

=head2 user

The user doing the deployment (for audit logging purposes).

=cut

has user => (
    is          => 'ro',
    isa         => 'Str',
    required    => 1,
);

for my $method (qw{ deploy dbsync dbrebuild export }) {

    around $method => sub {
        my ($orig, $self) = (shift, shift);

        my $ret = $self->$orig(@_);
        $self->_log($method, $ret);

        return $ret;
    };
}

sub _log {
    my ($self, $action, $ret) = @_;

    my $schema = $self->instance->result_source->schema;

    # XXX: apart from result, can this message be pre-computed?
    $schema->resultset('AuditLog')->log($self->user, $action, {
            success => $ret,
            client => $self->instance->survey->client->client_tag,
            survey => $self->instance->survey->survey_tag,
            component => $self->component->id,
            deployment => $self->instance->deployment->name,
            generation => $self->instance->generation->name,
            revision => $self->instance->revision,
        });

    # XXX: should this be done with a 'summary' method on various objects,
    # eg.  { ret => $ret, %{ $self->instance->summary },
    #        %{ $self->component->summary } }
    # instance->summary would call survey/deployment/generation summary
    #                   and include revision
    # survey->summary would call client->summary and include survey tag
    # (just a thought)
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::Deployment - abstract class that defined the deployment api

=cut

