package SD::Tempest::Util::DeploymentTree;
use 5.14.1;
use Moose;
use namespace::autoclean;

with 'SD::Tempest::Role::Schema';
with 'SD::Tempest::Role::SVN::Client';

use MooseX::StrictConstructor;
use File::Temp;
use Data::Dumper::Concise;

use SD::Tempest::Configuration;
use SD::Tempest::Mutator::Component;
use SD::Tempest::Mutator::SurveyInstance;
use SD::Tempest::SVN::Client;

has config => (
    is          => 'ro',
    isa         => 'HashRef',
    lazy        => 1,
    default     => sub { SD::Tempest::Configuration->config },
);

# lazy build schema and svn client, please.
has '+schema'     => ( lazy_build  => 1 );
has '+svn_client' => ( lazy_build => 1 );

sub generate_deployment_tree {
    my ($self, $dest) = @_;

    die "No destination dir specified" unless $dest;
    Path::Class::Dir->new($dest)->absolute->mkpath; # make dest path

    # Find all inactive instances
    my $instance_rs = $self->schema->resultset('SurveyInstance')->search(
        { inactive => [ undef, { '!=' => 1 } ] },
        {
            prefetch => [ { 'survey' => 'client' },
                          { 'instance_generation' => 'generation' },
                          'deployment'
            ],
            order_by => [ 'deployment.name', 'client_tag', 'survey_tag' ],
        } 
    );
    # XXX - this is not very efficient - we export the svn content twice
    # once to inflate all the SD::Tempest::Component objects
    # and a second time to build the tree structure.
    while ( my $instance = $instance_rs->next ) {
        # Checkout instance and get all components
        my $mutator = SD::Tempest::Mutator::SurveyInstance->new(
            svn_client => $self->svn_client,
            instance   => $instance,
        );
        # For every component, write (move) to
        # $dest/$generation/$deployment/$uuid
        for my $component ( $mutator->components ) {
            if ( $component->config_is_unreadable ) {
                $self->report_unreadable( $instance );
            } else {
                say sprintf "Exporting g: %8s d: %12s c: %20s s: %20s id: %40s",
                    $instance->generation->name,
                    $instance->deployment->name,
                    $instance->survey->client->client_tag,
                    $instance->survey->survey_tag,
                    $component->config->{survey_name};
                my $dir = Path::Class::Dir->new( $dest,
                    $instance->generation->tag,
                    $instance->deployment->name,
                    $component->config->{survey_name} )->absolute;
                # If this directory exists, then two surveys have the same survey_name
                die "Duplicate survey_name" if -e $dir;
                $dir->parent->mkpath;
                my $cm = SD::Tempest::Mutator::Component->new(
                    mutator   => $mutator,
                    component => $component
                );
                $cm->export_content( $dir );
            }
        }
    }
}

sub report_unreadable {
    my ( $self, $instance ) = @_;
    say sprintf "g: %8s d: %12s c: %12s s:%12s - unreadable config",
        $instance->generation->name,
        $instance->deployment->name,
        $instance->survey->client->client_tag,
        $instance->survey->survey_tag;    
}

sub svn_path {
    my $self = shift; # @_ = ( client, survey, component )

    # The default repo config entry will end with 'development'
    # We don't want this.
    my $repo = $self->config->{repo};
    $repo =~ s{/?development/?$}{};

    return join '/', $repo, grep { defined } @_;
}

sub _build_schema {
    my $self = shift;
    return SD::Tempest::Schema->connect($self->config->{database});
}

sub _build_svn_client {
    my $self = shift;
    return SD::Tempest::SVN::Client->new(
        %{ $self->config->{ldap} },
    );
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=pod

=head1 NAME

SD::Tempest::Util::DeploymentTree - build deployment tree from tags table

=cut

