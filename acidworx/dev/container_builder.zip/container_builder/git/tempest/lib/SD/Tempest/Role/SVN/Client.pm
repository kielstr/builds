package SD::Tempest::Role::SVN::Client;

use Moose::Role;
use namespace::autoclean;

has svn_client => (
    is          => 'ro',
    isa         => 'SD::Tempest::SVN::Client',
    required    => 1,
);

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::SVN::Client - svn_client attribute

=head1 DESCRIPTION

Provides an svn_client attribute.

=cut
