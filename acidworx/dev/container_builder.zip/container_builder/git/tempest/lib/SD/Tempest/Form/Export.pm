package SD::Tempest::Form::Export;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler';

use namespace::autoclean;

has '+widget_wrapper' => ( default => 'Table' );
has '+widget_form' => ( default => 'Table' );

use namespace::autoclean;

# Regular Moose attribute - this is the default formatted format for this
# survey. eg. XLS
has formatted => (
    is          => 'ro',
    isa         => 'Str',
    required    => 1,
);

has_field format => (
    type            => 'Select',
    default_method  => sub { shift->form->formatted },
);

sub options_format {
    my ($self) = @_;
    return (
        YAML => 'Raw (YAML)',
        CSV  => 'CSV',
        XLS  => 'XLS',
        XLSX => 'XLSX',
        SPSS => 'CSV plus SPSS syntax',
    );
}

has_field meta => (
    type    => 'Boolean',
    label   => 'Use Meta',
    default => 0,
);

has_field submit => (
    type        => 'Submit',
    value       => 'Export',
);

has_field cancel => (
    type        => 'Submit',
    value       => 'Cancel',
);

## Blocks

has_block main => (
    render_list => [qw/format meta/],
);

has_block buttons => (
    render_list => [qw/submit cancel/],
);

sub build_render_list {
    return [qw/main buttons/];
}

## Methods

sub selected_format {
    my ($self) = @_;
    return $self->field('format')->value;
}

sub was_cancelled {
    my ($self) = @_;
    return defined $self->field('cancel')->input;
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::Form::Export - select export format and submit/cancel

=cut
