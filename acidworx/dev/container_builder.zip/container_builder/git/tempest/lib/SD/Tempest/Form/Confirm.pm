package SD::Tempest::Form::Confirm;
use warnings;
use strict;

use HTML::FormHandler;

use namespace::autoclean;

sub new {
    my ($class, $value, $form_id) = @_;

    my $form =  HTML::FormHandler->new(
        name => $form_id // 'confirm-form',
    	field_list => [
            submit => {type => 'Submit', value => $value},
            cancel => {type => 'Submit', value => 'Cancel'}
        ],
    );

    return $form;
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Form::Confirm - simple 'submit' button confirmation form

=head1 METHODS

=head2 new( $value, $form_id = 'confirm-form' )

Constructor. Returns a HTML::FormHandler instance with a single submit field
that will render with the value $value.

The form's id can be specified with $form_id. Defaults to 'confirm-form'.

=cut
