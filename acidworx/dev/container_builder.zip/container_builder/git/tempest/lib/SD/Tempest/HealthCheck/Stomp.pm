package SD::Tempest::HealthCheck::Stomp;
use 5.16.0;
use warnings;

use SD::Tempest::Configuration;
use Sys::SigAction qw( timeout_call );

use Log::Any qw( $log );

package StompClient {
    use Moose;
    with 'SD::Tempest::Role::Stomp';
};

sub check {
    # Net::STOMP::Client seems to retry forever if it can't connect, so force
    # the issue.
    my $timed_out = timeout_call 5, sub {
        my $stomp = StompClient->new;
        $stomp->stomp->disconnect;
    };

    die "STOMP connect timeout\n" if $timed_out;

    # Healthcheck.pm expects no return on success.
    return;
}

1;
