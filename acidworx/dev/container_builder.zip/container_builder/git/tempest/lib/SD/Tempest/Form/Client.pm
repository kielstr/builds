package SD::Tempest::Form::Client;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler::Model::DBIC';

use namespace::autoclean;

has '+item_class' => ( default => 'Client' );

has_field 'client_tag' => (
    type      => 'Text',
    label     => 'Client name',
    required  => 1,
    unique    => 1,
    size      => 30,
    maxlength => 50,
    apply     => [
        {
            check   => qr/^[a-z][a-z0-9\-]*$/,
            message => 'lowercase letters, digits and hyphens only'
        }
    ],
    messages  => {
        required => 'You must supply a valid client ID.',
    },
);

has_field 'submit' => (
    type => 'Submit',
    value => 'Create client',
);

__PACKAGE__->meta->make_immutable;
no HTML::FormHandler::Moose;

1;
