package SD::Tempest::Form::Survey;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler::Model::DBIC';

use namespace::autoclean;

has '+item_class' => ( default => 'Survey' );

has_field 'survey_tag' => (
    type      => 'Text',
    label     => 'Survey ID',
    required  => 1,
    unique    => 1,
    size      => 30,
    maxlength => 50,
    apply     => [
        {
            check   => qr/^[a-z][a-z0-9\-]*$/,
            message => 'lowercase letters, digits and hyphens only'
        }
    ],
    messages  => {
        required => 'You must supply a valid survey ID.',
    },
);

has_field 'survey_title' => (
    type      => 'Text',
    label     => 'Survey title',
    required  => 1,
    size      => 40,
    maxlength => 128,
    messages  => {
        required => 'You must give the survey a title.',
    },
    noupdate => 1,  # exclude this field from DBIC processing
);

has_field 'survey_pages' => (
    type      => 'Integer',
    label     => 'Pre-generated pages',
    required  => 1,
    size      => 2,
    maxlength => 2,
    default   => 3,
    apply     => [
        {
            check   => qr/^0?[1-9]|[1-9][0-9]$/,
            message => 'digits only; must be between 1 and 99 inclusive',
        }
    ],
    messages => {
       required => 'The page count must be between 1 and 99.',
    },
    noupdate => 1,  # exclude this field from DBIC processing
);

has_field 'submit' => (
    type => 'Submit',
    value => 'Create survey',
);



__PACKAGE__->meta->make_immutable;
no HTML::FormHandler::Moose;

1;
