package SD::Tempest::Role::SVN;

use Moose::Role;
use namespace::autoclean;

with 'SD::Tempest::Role::SVN::Client';
with 'SD::Tempest::Role::SVN::Path';

1;
__END__

=pod

=head1 NAME

SD::Tempest::Role::SVN - svn_client and svn_root attributes

=head1 DESCRIPTION

Consumes the SVN::Client and SVN::Root roles to provide both svn_root and
svn_client attributes.

=cut
