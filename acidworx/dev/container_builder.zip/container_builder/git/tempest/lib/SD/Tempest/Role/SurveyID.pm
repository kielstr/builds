package SD::Tempest::Role::SurveyID;

use Moose::Role;
use namespace::autoclean;

with 'SD::Tempest::Role::ClientID';

has survey_id => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::SurveyID',
    required    => 1,
);

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::ClientID - client_id & survey_id attributes

=head1 DESCRIPTION

Provides aclient_id & survey_id attributes.

=cut
