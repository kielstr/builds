package SD::Tempest::Role::ForeignItems;

use Moose::Role;

has _foreign_items => (
    isa         => 'ArrayRef[Path::Class::Entity]',
    traits      => ['Array'],
    default     => sub { [] },
    init_arg    => undef,
    is          => 'ro',
    handles     => {
        foreign_items     => 'elements',
        _add_foreign_item => 'push',
    },
);


1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::ForeignItems - Role to implement foreign items collection.

=head1 ATTRIBUTES

=head2 foreign_items

A list of (L<Path::Class::Entity>) objects representing file paths to
items that do not represent surveys, relative to the checkout root.

=head2 _add_foreign_item

Add a Path::Class::Entity item to the array.

Must be an object. Will not coerce pathlike strings.
This may be added in the future if required.

=cut

=head1 AUTHORS

=over

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2009, 2010 Strategic Data <http://strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.

#use namespace::autoclean;
