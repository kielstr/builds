package SD::Tempest::SVN::Client;
use 5.16.0;

use Moose;
use namespace::autoclean;

use MooseX::StrictConstructor;

use SD::Tempest::MooseTypes;

use Carp qw(croak);
use Data::Dumper::Concise;
use DateTime::Format::Strptime;
use XML::SAX;
use XML::Simple;
use IPC::Run ();
use Try::Tiny;
use Method::Signatures;

#------------------------------------------------------------------------------

has username => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::SVNUsername',
    predicate   => 'has_username',
);

has password => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::SVNPassword',
    predicate   => 'has_password',
);

has retry_timeout_sec => (
    is          => 'rw',
    isa         => 'Int',
    default     => 5,
);

#------------------------------------------------------------------------------

has _datetime_parser => (
    is          => 'ro',
    init_arg    => undef,
    lazy_build  => 1,
    handles     => {
        parse_datetime  => 'parse_datetime',
        format_datetime => 'format_datetime',
    },
);

sub _build__datetime_parser {
    # 2011-09-29T06:58:08.176317Z
    DateTime::Format::Strptime->new(pattern => '%FT%T.%6NZ');
}

has _svn_cmd => (
    is          => 'ro',
    init_arg    => undef,
    lazy_build  => 1,
);

method _build__svn_cmd() {

    my @cmd = qw( svn --non-interactive );
    if ($self->has_password) {
        push(@cmd, qw( --no-auth-cache ),
                   '--username' => $self->username,
                   '--password' => $self->password);
    }

    return \@cmd;
}

#------------------------------------------------------------------------------

sub BUILD {
    my ($self) = @_;

    croak('username and password must be specified together')
        if ($self->has_username != $self->has_password);
}

method add ($path) {
    return $self->_svn('add', $path);
}

method cat ($file, $revision) {
    return $self->_svn_stdout('cat', "$file\@$revision");
}

method checkout ($url, $path, $revision = 'HEAD') {
    return $self->_svn('checkout', "$url\@$revision", $path);
}

method commit ($path, $commit_msg = '(no commit message)') {

    # Get current revision info
    my $current_rev = $self->revision($path);

    my $new_revision = $self->_svn_revision('commit', -m => $commit_msg, $path);
    $new_revision //= $current_rev;

    return wantarray? ( $current_rev, $new_revision ) : $new_revision;
}

method delete ($path, $commit_msg?) {
    my @command = ( 'delete', $path );
    if (_is_repo_path($path)) {
        $commit_msg //= "Delete $path";
        return $self->_svn_revision(@command, -m => $commit_msg);
    }
    return $self->_svn(@command);
}

method export ($url, $path, $revision) {
    return $self->_svn('export', "$url\@$revision", $path);
}

method modified_items ($path) {
    my $listref = $self->_svn_xml('status', 'entry', $path)->{target}->{entry};
    my @modified = sort map { $_->{path} } @{ $listref };
    return @modified;
}

method list ($path, $revision) {
    my $hashref = $self->_svn_xml('list', 'entry', "$path\@$revision");
    return $hashref->{list}->{entry};
}

method revision_info ($path, $revision) {
    # Note: both $revision specs are required here.
    # $path@$revision means the snapshot we are looking at, and -r $revision
    # is the revision within that (or something)
    # Without the -r, you get *all* the commits that touch $path
    my $hashref = $self->_svn_xml('log', [qw( path )], '-v',
                  '-r' => $revision,
                  "$path\@$revision");

    return $hashref->{logentry};
}

method mkdir ($dir, $commit_msg?) {
    my @command = ( 'mkdir', '--parents', $dir );
    if (_is_repo_path($dir)) {
        # Making a directory on the repo performs a commit
        $commit_msg //= "Create $dir";
        return $self->_svn_revision(@command, -m => $commit_msg);
    }
    return $self->_svn(@command);
}

method move ($source, $destination, $commit_msg?) {
    my @command = ( 'move', $source, $destination );
    if (_is_repo_path($source)) {
        $commit_msg //= "Move $source to $destination";
        return $self->_svn_revision(@command, -m => $commit_msg);
    }
    return $self->_svn(@command);
}

method revision ($path) {
    return $self->_svn_info($path)->{commit}->{revision};
}

method repo_url ($path) {
    return $self->_svn_info($path)->{url};
}

method repo_root ($path) {
    return $self->_svn_info($path)->{root};
}

method update ($path, $revision = 'HEAD') {
    return $self->_svn('update', '-r' => $revision, $path);
}

method health_check($url) {

    # To test the connection, we do an import on /dev/null.
    # This will fail in this order:
    # 1) if the server is unavailable
    # 2) if the auth credentials are wrong
    # 3) /dev/null forces failure - which means we are healthy
    my ($success, $out, $err) = $self->_do_svn_cmd('import',
        -m => 'health-check', '/dev/null', $url);

    if ($err =~ m{'/dev/null' does not exist}) {
        # All's well.
        return 1;
    }

    if ($success) {
        # This just shouldn't happen.
        die "SVN health-check interal error for $url: $out$err\n";
    }

    die "SVN health-check failed for $url: $err\n";
}

#------------------------------------------------------------------------------

sub _diag {
    print STDERR Dumper(@_);
}

func _is_repo_path ($path) {
    return $path =~ m{\w+://};  # repo path has: xxx://.*
}

# Run an svn command and return ($success, $out, $err)
# Don't use this directly, use an _svn* method below.
method _do_svn_cmd ($cmd, @args) {
    my $command = [ @{ $self->_svn_cmd }, $cmd, @args ];

    #print STDERR "--> SVN ", join(' ', @$command), "\n";

    my ($in, $out, $err);
    my $success;
    my $timeout_time = time + $self->retry_timeout_sec + 1;
    while (time < $timeout_time) {
        my $retry;
        undef $err; # make sure we don't get an old fork message left over
        try {
            $success = IPC::Run::run($command, \$in, \$out, \$err);
        }
        catch {
            # IPC::Run::run adds 'during fork' to the error message if
            # the fork failed. This will fail if that message changes, so
            # make sure there's a test for this. (Easier said than done...)
            $err = $_;
            $retry = ($err =~ /during fork/);
        };
        last unless $retry;
    }

    #print STDERR '==> ', $success ? 'OK! ' : 'ERR ', $out // $err // '', "\n";

    return ($success, $out, $err);
}

# _do_svn_cmd wrapper which returns $success and croaks on failure
method _svn ($cmd, @args) {
    my ($success, $out, $err) = $self->_do_svn_cmd($cmd, @args);
    _croak($cmd, $err) unless $success;
    return $success;
}

# _do_svn_cmd wrapper which returns $stdout and croaks on failure
method _svn_stdout ($cmd, @args) {
    my ($success, $out, $err) = $self->_do_svn_cmd($cmd, @args);
    _croak($cmd, $err) unless $success;
    return $out;
}

# _svn_stdout wrapper which forces --xml, and parses XML from $stdout
method _svn_xml ($cmd, $force_array, @args) {
    $force_array = [ $force_array ]
        unless ref $force_array eq 'ARRAY';

    my $xml = $self->_svn_stdout($cmd, '--xml', @args);
    my $hashref = XMLin($xml, ForceArray => $force_array);
    return $hashref;
}

# _svn_xml wrapper which calls svn info
method _svn_info ($path) {
    return $self->_svn_xml('info', [], $path)->{entry};
}

# Perform svn command, and return new revision
method _svn_revision($cmd, @args) {

    # Do commit
    my $out = $self->_svn_stdout($cmd, @args);
    return unless length $out;

    # Extract new svn revision from output
    $out =~ /Committed revision (\d+)\./
        or _croak('commit', "Unexpected error: $out");

    return $1;
}

func _croak ($cmd, $err) {
    croak("svn $cmd: $err");
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::SVN::Client - SVN::Client sorta-workalike in SVN::Class

=head1 DESCRIPTION

SVN::Client proved to be problematic with its Alien::SVN dependencies.

SVN::Class was chosen as a suitable alternative as it uses only the 'svn'
binary.

SD::Tempest::SVN::Client is a compatibility layer which implements SVN::Client
using SVN::Class, with a few differences.

Only the functionality currently required by Tempest has been implemented. If
you get an C<unimplemented> exception, feel free to add the functionality here.

In many cases it will be just a matter of removing the parameter check. I'm
just being paranoid really - I can't test the missing functionality as I have
no comparison between the old and new behaviours.

=head1 METHODS

Unless otherwise specified, use C<svn help command> for more explanation of
the methods below.

Unless otherwise specified, all commands below throw an exception on error.

=head2 new ( username => $username, password => $password )

Constructor.

Username and password are optional, but if they are specified, must be specified
as a pair.

=head2 add ( $path )

Schedule C<$path> for addition to the repository.

=head2 cat ( $file_url )

Returns the contents of $file_url.

=head2 checkout ( $url, $path, $revision = 'HEAD' )

Checkout from C<$url> to C<$path> at the specified C<$revision>.

=head2 commit ( $path, $commit_msg = '(no commit message') )

Commit the object to the repository with the log message.

In list context, returns the previous and new revision numbers;
Otherwise returns the new (or last, if no commit made) revision number.

Croaks if no revision number can be extracted from the svn output.

=head2 delete ( $object, $commit_message? )

If C<$object> is a local file, removes the C<$object> from the local filesystem
and adds it the modified items list to be committed later. Commit message is
ignored. Returns success.

If C<$object> is a repo url, immediately commits the delete in the repo, and returns the new revision.

=head2 modified_items ( $path )

Return a list of modified items under C<$path>.

=head2 mkdir ( $path, $commit_message? )

Create a directory. Subdirectories will be created if necessary (like mkdir -p).

If C<$path> is local, creates the directory locally, and adds it to the modified
items list to be committed later. Commit message is ignored. Returns success.

If C<$path> is a repo url, immediately commits the new directory in the repo,
and returns the new revision.

=head2 move ( $source, $destination, $commit_message? )

Move from C<$source> to C<$destination>.

If paths are local, moves the objects directory locally, and adds to the
modified items list to be committed later. Commit message is ignored. Returns
success.

If paths are repo urls, immediately commits the operation in the repo, and
returns the new revision.

=head2 revision ( $path )

Get the revision number of C<$path>.

=head2 revision_info ( $path, $revision )

Return a hashref containing full commit info for $path at $revision.
Returns undef if $path is not included in commit.

=head2 update ( $path, $revision = 'HEAD' )

Get the specified version of C<$path> from the repository.

=head2 health_check ( $repo_url_and_path )

Verify that the server is available, and the user credentials are good.

=cut

