package SD::Tempest::PerlConfigLoader;

=head1 NAME

SD::Tempest::PerlConfigLoader - Load component C<config.pl> files

=head1 SYNOPSIS

    my $conf = SD::Tempest::PerlConfigLoader->config_from('config.pl');

=head1 DESCRIPTION

A module to load the configuration hash found in a WebSurvey component.

=cut

use Moose;
use namespace::autoclean;

use File::chdir;
use Path::Class::Dir ();
use Scope::Guard ();

use SD::Config ();
use SD::Tempest::MooseTypes ();

=head1 METHODS

=head2 config_from( $file )

Class method to construct an instance and return its L</config>.

=cut

sub config_from {
    my ($class, $file) = @_;
    return $class->new( file => $file )->config;
}

=head2 new( file => $file )

Constructor.  L</file> is required.

=head2 file

The location of the C<config.pl> file for a WebSurvey component.

=cut

has file => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::File',
    coerce      => 1,
    required    => 1,
);

=head2 config

A hash reference to the loaded configuration.  May die if the
configuration cannot be loaded.

=cut

has config => (
    is          => 'ro',
    isa         => 'HashRef',
    lazy        => 1,
    default     => \&_retrieve_config,
);

=head1 INTERNAL METHODS

=head2 _retrieve_config

Called when the L</config> method is first called on an object.
Attempts to load the specified file.

=cut

sub _retrieve_config {
    my ($self) = @_;

    # We try to ask the config not to load the survey's content, but in
    # some cases it will try to anyway and assume a particular working
    # directory.
    local $ENV{'SD_NO_CONTENT'} = 1;
    local $CWD = $self->file->parent;

    # Historically SD::Config::load_defaults was overridden to return
    # an empty hash, but Tempest's template config.pl relies on default
    # (or more accurately, upstream) information to finalise itself.

    # We can't "do" the config directly because many configs ascertain
    # their locations through @SD::Config::loading, which is set by
    # SD::Config::load.  This tries to cache configs by filename
    # though, and under Tempest configs may change across requests, so
    # delete any cached data first.
    local %SD::Config::cache = ();
    return SD::Config->load($self->file);
}

__PACKAGE__->meta->make_immutable;
1;

__END__

=head1 AUTHORS

=over

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2009 Strategic Data <http://www.strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.
