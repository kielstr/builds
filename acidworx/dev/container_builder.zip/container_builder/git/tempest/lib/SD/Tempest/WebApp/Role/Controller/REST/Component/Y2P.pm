package SD::Tempest::WebApp::Role::Controller::REST::Component::Y2P;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use SD::Tempest::Form::Confirm;

requires 'component_mutate';

###############
## Action stubs

sub y2p : Chained('component_mutate') PathPart('y2p') Args(0) ActionClass('REST::ForBrowsers') {}

sub y2p_result: Chained('component_mutate') PathPart('y2p') Args(1) ActionClass('REST::ForBrowsers') {}

##############
## REST methods

sub y2p_POST_html : Private {
    my ($self, $c) = @_;

    $c->stash->{'template'} = 'rest/component_y2p.tt';

    # Fetch any past y2p output
    my $component = $c->stash->{'ws_component'};

    my $prev_recs = $c->model("DB::ContentGeneration")->search(
        {
            component_id    => $component->config->{'survey_name'},
        },
        {
            order_by        => { -desc => [qw{ requested_at }] },
            rows            => 10,
        },
    );
    $c->stash->{'previous_generations'} = $prev_recs;

    # Only allow further action if a content.yaml file actually exists.
    $c->detach if not $component->has_content_yaml;

    # Ensure form was submitted
    my $label = 'Generate';
    $c->stash->{'form'} = SD::Tempest::Form::Confirm->new($label);
    return unless $c->stash->{'form'}->process(
        params => $c->request->params,
    );
    my ($input) = grep { defined } map { $_->input } $c->stash->{'form'}->fields;
    unless ( $input eq $label ) {
        my $redirect = $c->uri_for(
            '/client', $c->stash->{client}->client_tag, 'survey',
            $c->stash->{survey}->survey_tag, 'instance'
        );
        $c->response->redirect( $redirect );
        $c->detach;
    }

    my $user = $c->stash->{user} // 'sd-dev-tempest',

    my ($success, $old_rev, $new_rev, $stderr)
        = $c->stash->{'commutator'}->y2p;
    my $db = $c->model('DB::ContentGeneration')->create({
        component_id        => $component->config->{'survey_name'},
        initial_svn_rev     => $old_rev,
        requested_by        => $user,
        requested_at        => DateTime->now,
        failure             => ($success ? 0 : 1),
        y2p_stderr          => (defined $stderr ? $stderr : ''),
        final_svn_rev       => $new_rev,
    });
    my $db_id = $db->content_generation_id;

    my $message_ids = [];
    my $redirect;

    if (not $success) {
        push @$message_ids, $c->set_error_msg(
            'The generation process did not succeed.  Please '
            . 'review the output below to identify the problem.'
        );
       $redirect = $c->uri_for(
            $c->request->uri->path,
            $db_id,
       );
    }
    elsif (not defined $new_rev) {
        push @$message_ids, $c->set_status_msg(
            'The content.pl file for this survey is already '
            . 'up-to-date; generation is not necessary.'
        );
    }
    else {
        $c->stash->{'commutator'}->deploy($user,1); # y2p needs a restart

        push @$message_ids, $c->set_status_msg(
            'The generation process succeeded.  Any necessary '
            . 'database changes will take place shortly.'
        );

        my $alerts = [];
        # Test for duplicate slot names
        if ( $stderr =~ m/^\!\!\! Possible duplicate slot/m ) {
            # This is a bit hacky and dependent on Y2P output not changing.
            # but less of a PITA with using another external script..
            push @$alerts, 'There were duplicate slot names detected.';
        }

        # Check for other (non-fatal) YAML warnings and alert user
        if ( $stderr =~ m/^YAML Warning: (.*)$/m ) {
            push @$alerts, "There were YAML warnings: <$1>."
        }

        push @$message_ids, $c->set_error_msg(
            join("\n",
                @$alerts,
                'Please check the y2p output for further details.'
            )
        ) if scalar @$alerts;

    }

    $redirect //= $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $message_ids }
    );
    $c->response->redirect( $redirect );

}

sub y2p_POST : Private {
    my ($self, $c) = @_;

    $c->detach('y2p_POST_html') unless $c->request->data;

    my $user = $c->stash->{user} // 'sd-dev-tempest',
    my $component = $c->stash->{'ws_component'};

    my ($success, $old_rev, $new_rev, $stderr)
        = $c->stash->{'commutator'}->y2p;
    my $db = $c->model('DB::ContentGeneration')->create({
        component_id        => $component->config->{'survey_name'},
        initial_svn_rev     => $old_rev,
        requested_by        => $user,
        failure             => ($success ? 0 : 1),
        y2p_stderr          => (defined $stderr ? $stderr : ''),
        final_svn_rev       => $new_rev,
    });
    my $db_id = $db->content_generation_id;

    if (not $success) {
        # Failure
        $self->status_bad_request( $c,
            message => "y2p failed. See " . $c->request->uri .
                       "/$db_id for result",
        );
    } elsif (not defined $new_rev) {
        # No Change
        $self->status_no_content( $c );
    } else {
        # Success
        $self->status_created( $c,
            location => join('/',$c->request->uri,$db_id),
            entity => {
                status => 'success',
            }
        );
    }
}

sub y2p_result_GET : Private {
    my ($self, $c, $id) = @_;

    return $self->status_bad_request( $c,
        message => 'invalid y2p result id'
    ) unless $id =~ m/^\d+$/;

    my $component = $c->stash->{'ws_component'};
    my $config = $component->config;
    my $record = $c->model('DB::ContentGeneration')->search({
        component_id            => $config->{'survey_name'},
        content_generation_id   => $id,
    })->single;
    $c->stash->{'result'} = $record;

    unless ( $c->stash->{'result'} ) {
        $self->status_not_found( $c,
            message => 'y2p generation result not found',
        );
        $c->detach();
    }

    my $component_path = $component->svn_path;
    my $base_path = $c->config->{repo};
    $component_path =~ s{$base_path/*}{};
    $c->stash(
        template        => 'rest/component_y2p_result.tt',
        trac_url        => $c->config->{'trac_url'},
        component_path  => $component_path,
    );

    return $self->status_ok($c,
        entity => { $c->stash->{'result'}->get_columns }
    );
}

1;

