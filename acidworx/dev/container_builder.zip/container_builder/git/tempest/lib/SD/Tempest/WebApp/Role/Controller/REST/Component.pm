package SD::Tempest::WebApp::Role::Controller::REST::Component;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use Hash::Merge::Simple;
use Try::Tiny;

use SD::Tempest::Exceptions;
use SD::Tempest::Form::Component;
use SD::Tempest::Form::Confirm;
use SD::Tempest::Form::Sessions;

has component_form => (
    is  => 'ro',
    isa => 'SD::Tempest::Form::Component',
    default => sub { SD::Tempest::Form::Component->new },
);


###################
# Scaffolding stubs

sub component_base : Chained PathPart(';') CaptureArgs(0) {}

sub component_find : Chained('component_base') PathPart('') CaptureArgs(1) {
    my ($self, $c, $id) = @_;

    # Single component surveys *may* have a name of '' (or undef);
    # Expressing that in a URI is dangerous, as many proxies simplify paths
    # i.e.  'foo//bar' to 'foo/bar'.
    # We work around this by using a "placeholder" of '~default' for such surveys
    $id = '' if $id eq '~default';

    # NOTE: 'component' is a *special* variable to Template::Toolkit
    $c->stash->{'ws_component'} = $c->stash->{'mutator'}->component($id);

    unless ( $c->stash->{'ws_component'} ) {
        $self->status_not_found( $c,
            message => 'component not found',
        );
        $c->detach('end');
    }

}

sub component_mutate : Chained('component_find') PathPart('') CaptureArgs(0) {
    my ($self, $c) = @_;
    $c->stash->{'commutator'} = SD::Tempest::Mutator::Component->new(
        mutator   => $c->stash->{'mutator'},
        component => $c->stash->{'ws_component'},
    );
}

###############
## Action stubs

sub component : Chained('component_base') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

sub component_single : Chained('component_find') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

# export REST actions
with 'SD::Tempest::WebApp::Role::Controller::REST::Component::Export';

# y2p REST actions
with 'SD::Tempest::WebApp::Role::Controller::REST::Component::Y2P';

# properties REST actions
with 'SD::Tempest::WebApp::Role::Controller::REST::Component::Properties';

sub rebuilddb : Chained('component_mutate') PathPart('rebuilddb') Args(0) ActionClass('REST::ForBrowsers') {}

sub sessions : Chained('component_mutate') PathPart('sessions') Args(0) ActionClass('REST::ForBrowsers') {}

##############
# REST methods

sub component_GET : Private { # Return list of components
    my ($self, $c) = @_;
    
    return $self->status_ok( $c,
        entity => { components => $c->stash->{mutator}->components }
    );
}

sub component_POST_html : Private { # Add a new component via a form
    my ($self, $c) = @_;

    $c->stash->{'template'} = 'rest/component_new.tt';

    # Add form and empty client object to the stash
    $c->stash->{form} = $self->component_form;

    # Process form
    $c->detach unless $self->component_form->process(
        params => $c->request->params,
    );

    my $mutator = $c->stash->{'mutator'};
    my $form = $self->component_form;

    # Extra validation
    if (
        # mutator->component will return the only component for a single component
        # survey. If a component is returns, double check their ids.
        $mutator->component( $form->field('id')->value ) &&
        $mutator->component( $form->field('id')->value )->id eq $form->field('id')->value
     ) {
        $c->stash->{'error'}
            = 'The specified ID is already in use for this survey.  '
            . 'Please choose another ID.';
        $c->detach;
    }
    if (
        $form->field('id')->value eq 'default'
        and not $mutator->is_multi_component
    ) {
        $c->stash->{'error'}
            = 'The ID "default" is reserved for the existing '
            . 'component.  Please choose another ID.';
        $c->detach;
    }

    my $error;
    try {
        $mutator->make_multi_component('default');

        # Grab the default URL templates from Tempest's configuration, and
        # slot the client and survey IDs into them.
        my $urls = {};
        my $deploy_rs = $c->model('DB::Constraint::Deployment')->search({});
        while ( my $deploy = $deploy_rs->next ) {
            next unless exists $c->config->{'default_url'}->{$deploy->name};
            my $url = $c->config->{'default_url'}->{$deploy->name};
            $url =~ s/CLIENT/$c->stash->{'client'}->client_tag/eg;
            $url =~ s/SURVEY/$c->stash->{'survey'}->survey_tag/eg;
            $url =~ s{/$}{};
            $url .= '/' . $form->field('id')->value;
            $urls->{$deploy->name} = $url;
        }

        $mutator->create_component(
            id      => SD::RandomToken->new,
            name    => $form->field('id')->value,
            title   => $form->field('title')->value,
            pages   => $form->field('pages')->value,
            urls    => $c->model('DB::Constraint::Deployment')->default_urls(
                $c->stash->{'client'}->client_tag,
                $c->stash->{'survey'}->survey_tag,
                $form->field('id')->value
            ),
            user    => $c->stash->{user} // 'sd-dev-tempest',
        );
    }
    catch {
        $error = $_;
    };

    my $msg_id;
    if ($error) {
        if (SD::Tempest::SVN::StaleCommit->caught($_)) {
            $msg_id = $c->set_error_msg( q{
                The new component was not created. Please update from latest
                SVN and try again.
            });
        }
        else {
            die $error;
        }
    }
    else {
        $msg_id = $c->set_status_msg( q{
            The new component has been created.  Development may commence
            immediately.  You will be emailed when the component reaches
            development servers and when the database is set up for it.
        });
    }
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub component_POST : Private { # Add a new component
    my ($self, $c) = @_;

    $c->detach('component_POST_html') unless $c->request->data;
    my $new_client_tag = $c->request->data->{'component_tag'};

    die "Not implemented yet"
}

sub component_single_GET : Private { # View component
    my ($self, $c) = @_;
}

sub rebuilddb_POST_html : Private {
    my ($self, $c) = @_;

    $c->stash->{template} = 'rest/component_rebuild_db.tt';

    # Ensure form was submitted
    my $label = 'Rebuild Database';
    $c->stash->{'form'} = SD::Tempest::Form::Confirm->new($label);
    return unless $c->stash->{'form'}->process(
        params => $c->request->params,
    );
    my ($input) = grep { defined } map { $_->input } $c->stash->{'form'}->fields;
    unless ( $input eq $label ) {
        my $redirect = $c->uri_for(
            '/client', $c->stash->{client}->client_tag, 'survey',
            $c->stash->{survey}->survey_tag, 'instance'
        );
        $c->response->redirect( $redirect );
        $c->detach;
    }

    my $msg_id;
    try {
        $c->stash->{'commutator'}->rebuild_db( $c->stash->{'user'} );
        $msg_id = $c->set_status_msg( q{
                The database rebuild has been queued, and should complete
                within a few minutes.  You will be emailed when the rebuild has
                completed.
            }
        );
    } catch {
        $msg_id = $c->set_error_msg("Database rebuild failed: $_");
    };

    # Redirect and show status message
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );

}

sub rebuilddb_POST : Private {
    my ($self, $c) = @_;

    $c->detach('rebuilddb_POST_html') unless $c->request->data;

    try {
        $c->stash->{'commutator'}->rebuild_db( $c->stash->{'user'} );
        $self->status_ok( $c,
            entity => { status => 'Rebuilt database' },
        );
    } catch {
        $self->status_bad_request( $c,
            message => "Rebuild failed: $_"
        );
    };
}

#XXX: should this go in Component::Mutator ?
sub _get_component_for_deployment {
    my ($commutator, $deployment, $svn_client) = @_;

    if ($deployment->name eq $commutator->instance->deployment->name) {
        # We already have the base component
        return $commutator->component;
    }

    my $base_instance =
        $commutator->instance->find_other_deployment($deployment);
    return unless $base_instance;

    return SD::Tempest::Mutator::SurveyInstance->new(
        instance => $base_instance,
        svn_client => $svn_client,
    )->component($commutator->component->id);
}

sub sessions_POST_html : Private {
    my ($self, $c) = @_;

    $c->stash->{template} = 'rest/component_sessions.tt';

    # We get the session filenames from the base component
    # eg testing/development
    my $base_deployment = $c->model('DB::Constraint::Deployment')
                            ->base_deployment;
    my $base_component = _get_component_for_deployment(
            $c->stash->{commutator},
            $base_deployment,
            $c->model('SVNClient'),
        );

    my $session_filenames = $base_component ?
            [ $base_component->session_filenames ] : [ ];

    my $form = $c->stash->{form} = SD::Tempest::Form::Sessions->new(
        sessions => $session_filenames,
    );

    $c->stash->{base_deployment}   = $base_deployment->name;
    $c->stash->{base_component}    = $base_component;
    $c->stash->{form}              = $form;
    $c->stash->{session_filenames} = $session_filenames;

    return unless $form->process( params => $c->request->params );

    my $msg_id;
    try {
        $c->stash->{commutator}->sync_db(
                $c->stash->{user},
                $base_component,
                $form->selected_session,
            );
        $msg_id = $c->set_status_msg( q{
                The database changes have been queued, and should complete
                within a few minutes.
            }
        );
    } catch {
        $msg_id = $c->set_error_msg("Database sync failed: $_");
    };

    # Redirect and show status message
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub sessions_POST : Private {
    my ($self, $c) = @_;

    $c->detach('sessions_POST_html') unless $c->request->data;

    # TODO: Ensure file is a scalar or an array ref.

    my $file = $c->request->data('file');
    # Genreate path names relative to component:
    my $survey_uuid = $c->stash->{component}->config->{survey_name};
    my @session_files = map { join("/", $survey_uuid, 'sessions', $_) }
        grep { defined } ref $file ? @$file : $file;

    return $self->status_bad_request( $c,
        message => "No session file specified"
    );

    try {
        $c->stash->{commutator}->sync_db( $c->stash->{user}, @session_files );
        $self->status_ok( $c, entity => { message => 'applying session files' } );
    } catch {
        $self->status_bad_request( $c,
            message => "Failed to apply sesison files: $_ "
        );
    };
}

1;

