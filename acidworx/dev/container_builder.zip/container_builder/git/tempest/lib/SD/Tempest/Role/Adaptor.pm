package SD::Tempest::Role::Adaptor;
use Moose::Role;
use namespace::autoclean;

use Class::Load qw(try_load_class);
use Log::Any qw($log);

has 'class' => (
    is       => 'ro',
    isa      => 'Str',
    required => '1',
);

has 'constructor' => (
    is       => 'ro',
    isa      => 'Str',
    default  => 'new',
);

sub _load_adapted_class {
    my ($self) = @_;
    my $adapted_class = $self->class;
    my ($rc, $error) = try_load_class( $adapted_class );
    $log->error("Failed to load $adapted_class: $error") unless $rc;
    return $rc;
}

sub _create_instance {
    my ($self, $rest) = @_;
    my $constructor = $self->constructor;
    my $adapted_class = $self->class;
    return $adapted_class->$constructor(
        $self->mangle_arguments($rest)
    );
}

sub mangle_arguments {
    my ($self, $args) = @_;
    return $args;
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::Adaptor - role for the 'adaptor' pattern

=head1 METHODS

=head2 _load_adapted_class

Load the adapted class

=head2 _create_instance

Instantiate the adapted class

=head2 mangle_arguments

Make the arguements amenable to the adapted class

=cut

