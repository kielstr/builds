package SD::Tempest::Form::Properties;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler';

use namespace::autoclean;

use Regexp::Common qw /URI/;
use Log::Any qw($log);

has '+use_defaults_over_obj' => ( default => 1 );

has 'user' => (
    is          => 'ro',
    isa         => 'Str',
    required    => 1,
);

has 'deployments' => (
    is          => 'ro',
    isa         => 'ArrayRef[Str]',
    required    => 1,
);

has 'default_urls' => (
    is          => 'ro',
    isa         => 'HashRef[Str]',
    required    => 1,
);

has_field 'title' => (
    type        => 'Text',
    label       => 'Survey Title',
);

has_field 'survey_urls' => (
    type        => 'Repeatable',
);

has_field 'survey_urls.type' => (
    type => 'Text',
    readonly => 1,
);

sub is_web_uri {
    my $addr = shift;
    my $regexp = $RE{URI}{HTTP}{-scheme => qr/https?/};
    return $addr =~ /^$regexp$/;
}

has_field 'survey_urls.url' => (
    type  => 'Text',
    apply => [
        {
            check   => sub { is_web_uri($_[0]) },
            message => sub { 'Malformed URL: ' . $_[0] . ' ' . is_web_uri($_[0]) }
        },
        {
            transform => sub { my $val = shift; $val =~ s/^http:/https:/; return $val; }, # always save https urls.
        },
    ],
);

has_field 'session_param_name' => (
    type     => 'Text',
    label    => 'Session parameter',
    apply    => [
        {
            check   => qr/^[A-Za-z0-9_\ \-]+$/,
            message => 'Letters, digits, underscores, hypnens and spaces only'
        }
    ],
    required => 1,
);

has_field 'submit' => (
    type => 'Submit',
    value => 'Update properties',
);

sub default_title {
    my ($self, $field, $item) = @_;

    return unless defined $item;

    if ( $item->component->title_is_settable ) {
        $field->disabled(0);
        return $item->component->properties->{'survey_title'};
    }

    $field->disabled(1);
    return 'Cannot change survey title';
};

sub default_session_param_name {
    my ($self, $field, $item) = @_;

    return unless defined $item;
    return $item->component->properties->{'session_parameter'};
}

sub default_survey_urls {
    my ($self, $field, $item) = @_;

    return unless $item && $item->component->properties;
    my $url = $item->component->properties->{frontend_urls} // {};

    # Add repeatable urls details
    my @urls = ();
    for my $deployment (@{ $self->deployments }) {
        push(@urls, {
            type => $deployment,
            url => $url->{$deployment} // $self->default_urls->{$deployment},
        });
    }

    return @urls;
}

sub update_model {
    my $self = shift;

    # Simple params first
    for my $field_name ( qw( title session_param_name ) ) {
        my $field = $self->field($field_name);
        my $method_name = "set_$field_name";
        $self->item->$method_name($self->user, $field->value);
    }

    # Then those pita urls
    for my $row ( @{ $self->field('survey_urls')->value } ) {
        my $deployment = $row->{type};
        my $url        = $row->{url};
        $self->item->set_url($self->user, $deployment, $url);
    }
}

__PACKAGE__->meta->make_immutable;
no HTML::FormHandler::Moose;

1;

