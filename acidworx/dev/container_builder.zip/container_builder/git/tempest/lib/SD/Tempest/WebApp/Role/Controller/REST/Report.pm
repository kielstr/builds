package SD::Tempest::WebApp::Role::Controller::REST::Report;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use SD::Tempest::Report::ActiveSurvey;

#############
# Scaffolding

sub report_base : Chained PathPart(';') CaptureArgs(0) {}


##############
# Action stubs

sub report : Chained('report_base') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}


##############
# REST methods

sub report_GET : Private { # Return list of active surveys
    my ($self, $c) = @_;

    return $self->status_ok( $c,
        entity => { SD::Tempest::Report::ActiveSurvey->new->fetch }
    );
}

sub report_GET_html : Private {
    my ($self, $c) = @_;

	$c->stash->{'template'} = 'rest/report/active_survey.tt';
	$c->stash->{'report'} = SD::Tempest::Report::ActiveSurvey->new->fetch;
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::WebApp::Role::Controller::REST::Report

=cut
