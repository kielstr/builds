package SD::Tempest::WebApp::Controller::REST;
use Moose;
use namespace::autoclean;

use SD::Tempest;
use SD::Platform;

BEGIN { extends 'Catalyst::Controller::REST' }

sub auto : Private {
    my ($self, $c) = @_;
    $c->forward('/login/ensure');
}

with qw/
    SD::Tempest::WebApp::Role::Controller::REST::Client
    SD::Tempest::WebApp::Role::Controller::REST::Report
    SD::Tempest::WebApp::Role::Controller::REST::Survey
    SD::Tempest::WebApp::Role::Controller::REST::Instance
    SD::Tempest::WebApp::Role::Controller::REST::Component
    /;

sub rest_base : Chained('/') PathPart('') CaptureArgs(0) {
    my ($self, $c) = @_;
    $c->stash->{ version } = $SD::Tempest::VERSION;
    $c->stash->{ universe } = SD::Platform->universe;
    $c->load_status_msgs;
}

sub serialize : ActionClass('Serialize') {}

sub end : Private {
    my ($self, $c) = @_;
    # Set a default template if an error has occured
    $c->stash->{'template'} ||= 'error.tt' if $c->res->status =~ m/^[4|5]/;
    $c->forward('serialize');
}

__PACKAGE__->config(
    action => {
        client_base    => { Chained => 'rest_base',        PathPart => 'client' },
        report_base    => { Chained => 'rest_base',        PathPart => 'report' },
        survey_base    => { Chained => 'client_find',      PathPart => 'survey' },
        instance_base  => { Chained => 'survey_find',      PathPart => 'instance' },
        component_base => { Chained => 'instance_mutator', PathPart => 'component' },
    },
    default   => 'text/html',
    stash_key => 'rest',
    map       => { # Defaults except for text/html
        'text/html'          => ['View', 'TT'],
        'text/xml'           => 'XML::Simple',
        'text/x-yaml'        => 'YAMLXS',
        'application/json'   => 'JSON',
        'text/x-json'        => 'JSON',
#        'text/x-data-dumper' => [ 'Data::Serializer', 'Data::Dumper' ],
#        'text/x-data-denter' => [ 'Data::Serializer', 'Data::Denter' ],
#        'text/x-data-taxi'   => [ 'Data::Serializer', 'Data::Taxi'   ],
#        'application/x-storable'   => [ 'Data::Serializer', 'Storable' ],
#        'application/x-freezethaw' => [ 'Data::Serializer', 'FreezeThaw' ],
#        'text/x-config-general'    => [ 'Data::Serializer', 'Config::General' ],
#        'text/x-php-serialization' => [ 'Data::Serializer', 'PHP::Serialization' ],
    }
);

__PACKAGE__->meta->make_immutable;

1;

