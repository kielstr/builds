package SD::Tempest::HealthCheck::Database;
use 5.16.0;
use warnings;

use SD::Tempest::Configuration;
use SD::Tempest::Schema;
use SD::Tempest::DeploymentHandler;

sub check {
    my $config = SD::Tempest::Configuration->config;

    my $schema = SD::Tempest::Schema->connect($config->{database});
    my $dh = SD::Tempest::DeploymentHandler->new(schema => $schema);

    # It's unlikely we'll have a version mismatch, but if there's a problem
    # connecting to the database, this will die somewhere.
    my $schema_version = $SD::Tempest::Schema::VERSION;
    my $database_version = $dh->current_version;
    if ($schema_version != $database_version) {
        die "Schema version $schema_version, "
          . "database version $database_version\n";
    }

    # Note that if you're trying to test this by hand in your browser, you'll
    # probably just get a 'Bad Request', and the session plugin tries to
    # access the database first, and it dies before we get here.

    # Healthcheck.pm expects no return on success.
    return;
}

1;
