package SD::Tempest::Role::SVN::Path;

use Moose::Role;
use namespace::autoclean;

has svn_path => (
    is          => 'ro',
    isa         => 'SD::Tempest::MooseTypes::URI',
    coerce      => 1,
    required    => 1,
);

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::SVN::Path - svn_path attribute

=head1 DESCRIPTION

Provides an svn_path attribute.

svn_path always points directly to the svn repo sub-path for the consuming
class.

=cut
