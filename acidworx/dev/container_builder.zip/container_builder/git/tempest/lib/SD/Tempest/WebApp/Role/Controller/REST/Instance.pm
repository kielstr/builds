package SD::Tempest::WebApp::Role::Controller::REST::Instance;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use SD::Tempest::Mutator::SurveyInstance;
use SD::Tempest::Form::Confirm;
use Try::Tiny;

#############
# Scaffolding

sub instance_base : Chained PathPart(';') CaptureArgs(0) {}

sub instance_find : Chained('instance_base') PathPart('') CaptureArgs(1) {
    my ($self, $c, $deployment) = @_;

    # Fetch it from the DB
    $c->stash->{'deployment'} = $deployment;
    $c->stash->{'instance'}   =
        $c->stash->{survey}->find_instance($deployment);

    unless ( $c->stash->{'instance'} ) {
        $self->status_not_found( $c,
            message => 'Instance not found',
        );
        $c->detach();
    }
}

sub instance_mutator : Chained('instance_find') PathPart('') CaptureArgs(0) {
    my ($self, $c) = @_;

    # Get mutator
    try {
        $c->stash->{mutator} = SD::Tempest::Mutator::SurveyInstance->new(
            instance   => $c->stash->{instance},
            svn_client => $c->model('SVNClient'),
        );
    } catch {
        $self->status_bad_request( $c,
            message => "Failed to create instance mutator: $_" );
    };

    $c->detach() unless $c->stash->{'mutator'};
}

##############
# Action stubs

sub instance : Chained('instance_base') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

sub instance_single : Chained('instance_find') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

sub status : Chained('instance_mutator') PathPart('status') Args(0) ActionClass('REST::ForBrowsers') {}

sub promote : Chained('instance_mutator') PathPart('promote') Args(0) ActionClass('REST::ForBrowsers') {}

sub update : Chained('instance_mutator') PathPart('update') Args(0) ActionClass('REST::ForBrowsers') {}

##############
# REST methods

sub instance_GET : Private {
    my ($self, $c) = @_;

    my $instances = $c->stash->{survey}->all_instances;
    return $self->status_not_found( $c,
        message => 'No instances found for this client/survey'
    ) unless scalar keys %$instances;

    # Turn objects into hashrefs
    my %instance_hashes = map {
            $_ => { $instances->{$_}->get_columns }
        } keys %$instances;

    return $self->status_ok( $c,
        entity => { instances => \%instance_hashes }
    );
}

sub instance_GET_html : Private {
    my ($self, $c) = @_;

    my $survey = $c->stash->{survey};

    my $instances = $survey->all_instances;

    return $self->status_not_found( $c,
        message => 'No instances found for this client/survey'
    ) unless scalar keys %$instances;

    my $svn_client = $c->model('SVNClient');

    my @deployment_names = $c->model('DB::Constraint::Deployment')->names;
    my @instance_info = map { {
            deployment => $_,
            instance   => $instances->{$_},
            can_modify => undef,
            upstream   => undef,
            downstream => undef,
            mutator    => $instances->{$_} ?
                SD::Tempest::Mutator::SurveyInstance->new(
                    instance => $instances->{$_},
                    svn_client => $svn_client,
                ) : undef,
        } } @deployment_names;

    # The base revision can be modified by tempest if
    #   * the instance is active
    #   * it is up-to-date with subversion.
    my $base_inst = $instance_info[0]->{instance};
    my $latest_revision = $svn_client->revision($base_inst->svn_path);
    $instance_info[0]->{can_modify} = ( ! $base_inst->inactive &&
        $latest_revision == $base_inst->revision);

    for (1 .. $#instance_info) {
        $instance_info[$_]->{upstream} = $instance_info[$_ - 1];
    }
    for (0 .. $#instance_info-1) {
        $instance_info[$_]->{downstream} = $instance_info[$_ + 1];
    }

    $c->stash->{instances} = \@instance_info; # for html view
    $c->stash->{svn_revision} = $svn_client->revision($instance_info[0]->{instance}->svn_path);

    return $self->status_ok( $c, entity => { } );
}

sub instance_single_GET : Private { # View instance
    my ($self, $c) = @_;

    $self->status_ok( $c,
        entity => {
            instance => $c->stash->{instance}->get_inflated_columns,
        },
    );
}

sub promote_POST_html : Private { # Confirmation form before promotion of instance
    my ($self, $c) = @_;

    $c->stash->{template} = 'rest/survey_promote.tt';

    # Ensure form was submitted
    my $label = 'Deploy';
    my $instance = $c->stash->{mutator}->instance;
    $c->stash->{form} = SD::Tempest::Form::Confirm->new($label);
    $c->stash->{redeploying} = $instance->downstream_instance ? 1 : 0;
    $c->stash->{target} = $instance->deployment->downstream->name;
    return unless $c->stash->{'form'}->process(
        params => $c->request->params,
    );
    my ($input) = grep { defined } map { $_->input } $c->stash->{'form'}->fields;
    unless ( $input eq $label ) { # i.e. Cancel button was clicked
        my $redirect = $c->uri_for(
            '/client', $c->stash->{client}->client_tag, 'survey',
            $c->stash->{survey}->survey_tag, 'instance'
        );
        $c->response->redirect( $redirect );
        $c->detach;
    }

    # Promote and redirect to instance list
    my $msg_id;
    try {
        my $new_instance = $c->stash->{mutator}->promote($c->stash->{user});
        my $deployment = $new_instance->deployment->name;
        $msg_id = $c->set_status_msg(
            "The survey has been promoted to $deployment."
        );
    } catch {
        $msg_id = $c->set_error_msg("Deployment failed: $_");
    };

    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub promote_POST : Private { # Promote current instance
    my ($self, $c) = @_;

    $c->detach('promote_POST_html') unless $c->request->data;

    try {
        my $instance = $c->stash->{mutator}->promote($c->stash->{user});
        my $deployment = $instance->deployment->name;
        $self->status_accepted( $c,
            location => join('/', $c->request->uri, '../../../',  $deployment),
            entity   => {
                status => "Deployed to $deployment",
            },
        )
    } catch {
        $self->status_bad_request( $c,
            message => "Promotion failed: $_" );
    };
}

sub update_POST_html : Private { # Update current instance from svn
    my ($self, $c) = @_;

    # Promote and redirect to instance list
    my $msg_id;
    try {
        $c->stash->{mutator}->update_from_svn($c->stash->{user});
        $msg_id = $c->set_status_msg(
            'The survey has been updated from SVN'
        );
    } catch {
        $msg_id = $c->set_error_msg("Deployment failed: $_");
    };

    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub update_POST : Private { # Update current instance
    my ($self, $c) = @_;

    $c->detach('update_POST_html') unless $c->request->data;

    try {
        $c->stash->{mutator}->update_from_svn($c->stash->{user});
        $self->status_accepted( $c,
            entity   => {
                status => "Updated from svn",
            },
        )
    } catch {
        $self->status_bad_request( $c,
            message => "Update failed: $_" );
    };
}

sub status_POST_html : Private {
    my ($self, $c) = @_;

    $c->stash->{template} = 'rest/survey_status.tt';

    # Ensure form was submitted
    my $label = $c->stash->{instance}->inactive ? 'Activate' : 'Deactivate';
    $c->stash->{status_label} = $label;
    $c->stash->{'form'} = SD::Tempest::Form::Confirm->new($label);
    return unless $c->stash->{'form'}->process(
        params => $c->request->params,
    );
    my ($input) = grep { defined } map { $_->input } $c->stash->{'form'}->fields;
    unless ( $input eq $label ) { # i.e. Cancel button was clicked
        my $redirect = $c->uri_for(
            '/client', $c->stash->{client}->client_tag, 'survey',
            $c->stash->{survey}->survey_tag, 'instance'
        );
        $c->response->redirect( $redirect );
        $c->detach;
    }

    # Toggle status
    my $msg_id;
    try {
        $c->stash->{instance}->update({
            inactive => $c->stash->{instance}->inactive ? 0 : 1 }
        );
        $c->stash->{instance}->discard_changes(); # reload
        my $new_status = $c->stash->{instance}->inactive ? 'deactivate' : 'activate';
        $c->stash->{mutator}->deploy( $c->stash->{user} );
        $msg_id = $c->set_status_msg(
            sprintf "The survey's %s instance has been %sd",
                $c->stash->{instance}->deployment->name, $new_status
        );
    } catch {
        $msg_id = $c->set_error_msg("Failed to toggle status: $_");
    };

    # Redirect with status message
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub status_POST : Private { # Set instance status
    my ($self, $c) = @_;

    $c->detach('status_POST_html') unless $c->request->data;

    try {
        $c->stash->{instance}->update(
            { inactive => $c->stash->{instance}->inactive ? 0 : 1 }
        );
        $c->stash->{instance}->discard_changes(); # reload
        my $new_status = $c->stash->{instance}->inactive ?
            'deactivate' : 'activate';
        $c->stash->{mutator}->deploy( $c->stash->{user} );
        $self->status_ok( $c,
            entity => {
                status => $new_status
            }
        );
    } catch {
        $self->status_bad_request( $c,
            message => "Status change failed: $_" );
    };
}

1;

