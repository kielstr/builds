package SD::Tempest::WebApp::Role::Controller::REST::Client;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use SD::Tempest::Form::Client;

has client_form => (
    is  => 'ro',
    isa => 'SD::Tempest::Form::Client',
    default => sub { SD::Tempest::Form::Client->new },
);

#############
# Scaffolding

sub client_base : Chained PathPart(';') CaptureArgs(0) {}

sub client_find : Chained('client_base') PathPart('') CaptureArgs(1) {
    my ($self, $c, $tag) = @_;

    $c->stash->{'client_id'} = $tag;

    # Fetch it from the DB
    $c->stash->{'client'} = $c->model( 'DB::Client' )->search(
        { 'client_tag' => $tag } )->single;           

    unless ( $c->stash->{'client'} ) {
        $self->status_not_found( $c,
            message => 'Client not found',
        );
        $c->detach('end');
    }

    push @{ $c->stash->{'nav'} }, {
        uri  => $c->uri_for('/client', $tag, 'survey'),
        text => "Client $tag",
    };
}

##############
# Action stubs

sub client : Chained('client_base') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

sub client_single : Chained('client_find') PathPart('') Args(0) ActionClass('REST::ForBrowsers') {}

##############
# REST methods

sub client_GET : Private { # Return list of clients
    my ($self, $c) = @_;

    return $self->status_ok( $c,
        entity => { clients => [ $c->model('DB::Client')->client_ids ] }
    );
}

sub client_POST_html : Private { # Add client via form
    my ($self, $c) = @_;

    $c->stash->{'template'} = 'rest/client_new.tt';

    # Add form and empty client object to the stash
    $c->stash->{form} = $self->client_form;
    $c->stash->{client} = $c->model('DB::Client')->new_result({});

    # Process form
    return unless $self->client_form->process(
        item   => $c->stash->{client},
        params => $c->request->params,
    );

    my $msg_id = $c->set_status_msg(
        sprintf "Client '%s' created.", $c->stash->{client}->client_tag
    );
    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        { mid => $msg_id}
    );
    $c->response->redirect( $redirect );
}

sub client_POST : Private { # Add client
    my ($self, $c) = @_;

    $c->detach('client_POST_html') unless $c->request->data;
    my $new_client_tag = $c->request->data->{'client_tag'};

    return $self->status_bad_request( $c,
        message => 'No client_tag defined in request' )
        unless defined $new_client_tag;

    return $self->status_bad_request( $c,
        message => 'Not a valid client_tag' )
            unless $new_client_tag =~ /^[a-z][a-z0-9\-]*$/;

    try {

        my $client = $c->model('DB::Client')->find_or_new(
            { client_tag => $new_client_tag });

        # Return 201 if that was a new client
        if ( ! $client->in_storage ) {

            $client->insert;
            return $self->status_created( $c,
                location => join('/', $c->request->uri, $new_client_tag ),
                entity   => {
                    status => 'created',
                    client => { $client->get_inflated_columns },
                },
            );

        } else {

            # Otherwise return 'found'
            return $self->status_found( $c,
                entity => {
                    status => 'found',
                    client => { $client->get_inflated_columns },
                },
            );

        }

    } catch {
        $self->status_bad_request( $c,
            message => "Can't create new client: $_ ");
    };
}

sub client_single_GET : Private { # View client
    my ($self, $c) = @_;

    return $self->status_ok( $c,
        entity => { $c->stash->{'client'}->get_inflated_columns }
    );
}

1;

