package SD::Tempest::Role::Stomp;
use Moose::Role;
use namespace::autoclean;

use SD::Tempest::Configuration;
require WS::Platform;
use SD::Platform;
use Log::Any qw($log);
use Net::STOMP::Client;
use Try::Tiny;
use JSON ();

my $json = JSON->new->utf8->canonical; # canonical sorts hash entries

# Set TEMPEST_DEBUG_STOMP to get STDERR messages from Net::STOMP::Client
if ($ENV{TEMPEST_DEBUG_STOMP}) {
    require No::Worries::Log;
    No::Worries::Log::log_filter(
        join("\n", qw( info debug trace error warning )));
}

has stomp =>  (
    is  => 'ro',
    isa => 'Net::STOMP::Client',
    lazy_build => 1,
);

sub _build_stomp {
    my $self = shift;

    my $uri = SD::Platform->stomp_uri;
    $log->debug("message='STOMP URI: $uri'");
    my %stomp_args = (
        uri => $uri,
        version => '1.1',
        timeout => {
            connect => 10,
            connected => 10,
            receive => 10,
            send => 10,
        },
    );
    $stomp_args{debug} = 'all' if $ENV{TEMPEST_DEBUG_STOMP};

    my $config = SD::Tempest::Configuration->config;
    my $stomp = Net::STOMP::Client->new(%stomp_args);
    $stomp->connect(
        host     => $config->{broker}{virtualhost},
        login    => $config->{broker}{login},
        passcode => $config->{broker}{passcode},
    );

    # RabbitMQ's temp-queue feature breaks frame validation in net-stomp-client
    # as of v1.2. I expect it to be fixed in a future version of RabbitMQ.
    # So we do this: (1==optional)
    $Net::STOMP::Client::Protocol::FieldFlags{"1.1"}{MESSAGE}{"subscription"} = 1;
    $Net::STOMP::Client::Protocol::FieldFlags{"1.1"}{ACK}{"subscription"} = 1;

    return $stomp;
}

sub send {
    return if $ENV{SD_TEMPEST_MOCKSTOMP}; # don't send anything
    my ( $self, %args ) = @_;
    my $body = delete $args{body};

    # Add platform settings as headers:
    my %plathash;
    for (WS::Platform->sd_platform_keys) {
        $plathash{"x-sd-$_"} = SD::Platform->$_;
    }

    $self->stomp->send(
        %plathash,
        %args,
        body => ref($body) ? $json->encode($body) : $body,
        receipt => $self->stomp->uuid(),
    );
    my $ok = 1;
    try {
        $self->stomp->wait_for_receipts(timeout => 10);
    }
    catch {
        $ok = 0;
        $log->error('Stomp send failed: ', $_);
    };
    return unless $ok;
    $log->warn('Stomp receipt not received') if $self->stomp->receipts();
    return $ok;
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Role::Stomp - stomp messaging client

=head1 METHODS

=head2 send

Wrapper around stomp->send() except that it encodes the body into JSON if you passed a
reference.

We wont send STOMP messages if ENV{SD_TEMPEST_MOCKSTOMP} is set.

=cut

