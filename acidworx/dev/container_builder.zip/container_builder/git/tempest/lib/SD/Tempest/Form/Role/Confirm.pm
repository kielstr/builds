package SD::Tempest::Form::Role::Confirm;
use HTML::FormHandler::Moose::Role;

for my $button (qw( submit cancel )) {
    has "${button}_button" => (
        is  => 'ro',
        isa => 'Str',
        default => ucfirst($button),
    );
}

has_field submit => (
    type            => 'Submit',
    default_method  => sub { shift->form->submit_button },
    order           => 10000,
);

has_field cancel => (
    type            => 'Submit',
    default_method  => sub { shift->form->cancel_button },
    order           => 10001,
);

sub was_cancelled {
    my ($self) = @_;
    return defined $self->field('cancel')->input;
}

1;

__END__

=pod

=head1 NAME

SD::Tempest::Form::Confirm - simple 'submit' button confirmation form

=head1 METHODS

=head2 new( $value? )

Constructor. Returns a HTML::FormHandler instance with a single submit field
that will render with the value $value.

=cut

__PACKAGE__->meta->make_immutable;
1;

__END__

=pod

=head1 NAME

SD::Tempest::Form::Export - select export format and submit/cancel

=cut
