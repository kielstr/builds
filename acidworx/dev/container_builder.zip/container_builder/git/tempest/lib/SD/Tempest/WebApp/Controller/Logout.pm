package SD::Tempest::WebApp::Controller::Logout;
use Moose;
use namespace::autoclean;

BEGIN { extends 'Catalyst::Controller' }

=head1 NAME

SD::Tempest::WebApp::Controller::Logout - Catalyst controller

=head1 DESCRIPTION

A Catalyst controller for logging out.

=head1 REGULAR ACTIONS

=head2 logout

Logs the user out.

=cut

sub logout : Path Args(0) {
    my ($self, $c) = @_;

    $c->flash->{'message'} = 'Logged out.' if $c->forward('do_logout');
    $c->response->redirect( $c->uri_for('/login') );
}

=head1 PRIVATE ACTIONS

=head2 do_logout

Performs the work necessary to actually log the user out.  Called from
both L</logout> and the login handler when a user is attempting to log
in, but a session already exists.

Returns a true value if a logout occurred.

=cut

sub do_logout : Private {
    my ($self, $c) = @_;

    return if not $c->user_exists;
    $c->model('DB::AuditLog')->log($c->user->id, 'logout');
    delete $c->session->{'fullname'};
    delete $c->session->{'password'};
    $c->logout;
    return 1;
}

__PACKAGE__->meta->make_immutable;

1;

__END__

=head1 AUTHORS

=over

=item Alex Peters <alex.peters@strategicdata.com.au>

=back

=head1 COPYRIGHT AND LICENSE

Copyright (c) 2009, 2010 Strategic Data <http://strategicdata.com.au/>.
All rights reserved.

This is proprietary software, not for redistribution or external use.
