package SD::Tempest::Form::Login;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler';

use namespace::autoclean;

has '+widget_wrapper' => ( default => 'Table' );
has '+widget_form' => ( default => 'Table' );

has_field 'username' => (
    type => 'Text',
    required => 1,
);

has_field 'password' => (
    type     => 'Password',
    required => 1,
);

has_field login => (
    type        => 'Submit',
    value       => 'Log in',
);

## Blocks

has_block main => (
    render_list => [qw/username password/],
);

has_block buttons => (
    render_list => [qw/login/],
);

sub build_render_list {
    return [qw/main buttons/];
}

__PACKAGE__->meta->make_immutable;
1;

