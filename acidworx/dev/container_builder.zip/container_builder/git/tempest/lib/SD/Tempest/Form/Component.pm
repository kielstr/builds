package SD::Tempest::Form::Component;
use HTML::FormHandler::Moose;
extends 'HTML::FormHandler';

use namespace::autoclean;

has '+widget_wrapper' => ( default => 'Table' );
has '+widget_form' => ( default => 'Table' );

has_field 'id' => (
    type      => 'Text',
    label     => 'Component ID',
    required  => 1,
    unique    => 1,
    size      => 30,
    maxlength => 50,
    apply     => [
        {
            check   => qr/^[a-z][a-z0-9\-]*$/,
            message => 'lowercase letters, digits and hyphens only'
        }
    ],
    messages  => {
        required => 'You must supply a valid component ID.',
    },
);

has_field 'title' => (
    type      => 'Text',
    label     => 'Component title',
    required  => 1,
    size      => 40,
    maxlength => 128,
    messages  => {
        required => 'You must give the component a title.',
    }
);

has_field 'pages' => (
    type      => 'Integer',
    label     => 'Pre-generated pages',
    required  => 1,
    size      => 2,
    maxlength => 2,
    default   => 10,
    apply     => [
        {
            check   => qr/^0?[1-9]|[1-9][0-9]$/,
            message => 'digits only; must be between 1 and 99 inclusive',
        }
    ],
    messages => {
       required => 'The page count must be between 1 and 99.',
    },
);

has_field 'submit' => (
    type => 'Submit',
    value => 'Create component',
);

__PACKAGE__->meta->make_immutable;
no HTML::FormHandler::Moose;

1;

