package SD::Tempest::WebApp::Role::Controller::REST::Component::Export;
use 5.16.0;
use MooseX::MethodAttributes::Role;
use namespace::autoclean;

use File::stat;
use SD::Tempest::Form::Export;
use Try::Tiny;

requires 'component_mutate';

###############
## Action stubs

sub export : Chained('component_mutate') PathPart('export') Args(0) ActionClass('REST::ForBrowsers') {}

sub export_file : Chained('component_mutate') PathPart('export') Args(1) ActionClass('REST::ForBrowsers') {}

##############
## REST methods

sub export_GET : Private {
    my ($self, $c) = @_; # Return list of files

    $c->stash->{template} = 'rest/component_export_list.tt';

    my @exports = $c->stash->{commutator}->get_export_list;

    $self->status_ok( $c, entity => { files => \@exports } );
}

sub export_POST_html : Private {
    my ($self, $c) = @_;

    $c->stash->{template} = 'rest/component_export.tt';

    my $export_config = $c->stash->{commutator}->component->config->{export};

    my $export_button = 'submit';
    my $form = $c->stash->{form} = SD::Tempest::Form::Export->new(
        formatted => $export_config->{format},
    );
    return unless $form->process(
        params => $c->request->params,
    );

    if ($form->was_cancelled) {
        my $msg_id = $c->set_status_msg('Export cancelled.');
        my $redirect = $c->uri_for(
            '/client', $c->stash->{client}->client_tag, 'survey',
            $c->stash->{survey}->survey_tag, 'instance',
            { mid => $msg_id }
        );
        $c->response->redirect( $redirect );
        $c->detach;
    }

    my @transforms;
    my $format = $form->selected_format;
    if ($format ne 'YAML') { # Not a raw YAML export
        push(@transforms, @{ $export_config->{Transform} });
    }

    # Queue export
    my $msg_id;
    try {
        $c->stash->{'commutator'}->queue_export(
            $c->stash->{user} // 'sd-dev-tempest',
            $format,
            \@transforms,
        );
        $msg_id = $c->set_status_msg('Export queued.');
    } catch {
        $msg_id = $c->set_error_msg("Export failed: $_");
    };

    my $redirect = $c->uri_for(
        '/client', $c->stash->{client}->client_tag, 'survey',
        $c->stash->{survey}->survey_tag, 'instance',
        { mid => $msg_id }
    );
    $c->response->redirect( $redirect );
}

sub export_POST : Private {
    my ($self, $c) = @_;

    $c->detach('export_POST_html') unless $c->request->data;

    my $export_config = $c->stash->{commutator}->component->config->{export};

    my $user = $c->stash->{user} // 'sd-dev-tempest';

    # Default to format in survey config if none supplied
    my $format = $c->request->data->{format} // '';
    $format = $export_config->{format} if $format !~ m/^[A-Za-z0-9]+$/;

    # Default to transforms in survey config if none supplied.
    my $transforms = $c->request->data->{transforms};
    $transforms = $export_config->{Transform} if ! defined $transforms;
    $transforms = [ $transforms ] if ! ref $transforms; # safety net..

    # Do we wait for a response from the toolchain?
    my $wait = !! $c->stash->{wait};

    try {
        my $res = $c->stash->{'commutator'}->queue_export(
            $user, $format, $transforms, $wait
        );
        # Merge in response, if it is a hashref.
        $self->status_accepted( $c,
            entity => {
                status => 'export queued',
                ref $res eq 'HASH' ? %$res : (),
            }
        );
    } catch {
        $self->status_bad_request( $c, message => "Export failed: $_" );
    };
}

sub export_file_GET : Private {
    my ($self, $c, $filename ) = @_; #Serves file content

    return $self->status_bad_request( $c, message => "No filename supplied" )
        unless defined $filename && length($filename);

    my $file = $c->stash->{commutator}->export_file_path->file($filename)->absolute->resolve;
    return $self->status_not_found( $c, message => "File not found: $filename")
        unless -e $file;

    # send_static_file + set dispoition
    my $type = $c->_ext_to_type( $file );
    my $stat = stat $file;

    $c->response->headers->content_type( $type );
    $c->response->headers->content_length( $stat->size );
    $c->response->headers->last_modified( $stat->mtime );
    # Tell Firefox & friends its OK to cache, even over SSL:
    $c->response->headers->header('Cache-control' => 'public');

    my $as = $c->request->params->{as} // '';
    if ( $as =~ m!^[a-z0-9-_.]+$!i ) {
        $c->response->headers->header(
            'Content-Disposition' => "attachment; filename=\"$as\""
        );
    }

    my $fh = IO::File->new( $file, 'r' );
    if ( defined $fh ) {
        binmode $fh;
        $c->res->body( $fh );
    }
    else {
        Catalyst::Exception->throw(
            message => "Unable to open $file for reading" );
    }

    return 1;
}

sub export_file_DELETE : Private {
    my ($self, $c, $filename) = @_;

    return $self->status_bad_request( $c, message => "No filename supplied" )
        unless defined $filename && length($filename);

    return $self->status_bad_request( $c,
        message => "Invalid filename: '$filename'"
    ) if $filename =~ m/\.\./; # don't allow relative file paths

    my $file = $c->stash->{commutator}->export_file_path->file($filename);

    eval {
        # The resolve call dies if the file does not exist
        $file = Path::Class::File->new($file)->absolute->resolve;
    };

    # Check if file exists
    if ( ! (defined $file && -f $file) ) {
        $self->status_not_found(
            $c,
            message => 'Export file does not exist',
        );
        $c->detach;
    }

    # Unlink ..
    my $rc = $file->remove;

    # Verify we deleted a file
    if ( ! $rc ) {
        $self->status_bad_request(
            $c,
            message => 'Failed to unlink file',
        );
        $c->detach;
    }
    $self->status_accepted( $c, entity => { status => 'Deleted'} );
}

1;

